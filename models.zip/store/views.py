
# store/views.py
import logging
import os 
import uuid
import json
import requests
from decimal import Decimal
from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required,user_passes_test
from django.contrib.auth.models import User
from django.contrib import messages
from django.db.models import Q, Sum, Count, F
from django.db.models.functions import TruncMonth
from django.utils.text import slugify
from django.contrib.auth import login as django_login, logout as django_logout
from django.conf import settings
from django.urls import reverse
from django.http import HttpResponse, Http404
from django.template.loader import render_to_string
from supabase import create_client
from paystackapi.paystack import Paystack
from django.utils import timezone
from django.views.decorators.csrf import csrf_exempt
from datetime import datetime, timedelta
from django.contrib.admin.views.decorators import staff_member_required
from django.db.models.functions import TruncDay,TruncHour
from datetime import timezone as dt_timezone
from django.views.decorators.http import require_POST
from django.db import transaction, IntegrityError
from django.contrib.auth import login
from django.core.mail import send_mail

# ==================== AI CHATBOT (OpenRouter) ====================
OPENROUTER_API_KEY = os.environ.get("OPENROUTER_API_KEY")
OPENROUTER_URL = "https://openrouter.ai/api/v1/chat/completions"
OPENROUTER_MODEL = "openai/gpt-4o-mini"  # any model id from https://openrouter.ai/models
# Initialize Paystack
paystack = Paystack(secret_key=settings.PAYSTACK_SECRET_KEY)

from .models import Product, Category, Cart, CartItem, SharedCartLink, CartInvite, Order, OrderItem, SellerProfile, UserProfile, Review,Region, PageView, UserNotification
from .models import Conversation, ChatMessage, Invoice
from .forms import CustomUserCreationForm, CustomAuthenticationForm, SellerSignupForm, ProductUploadForm, ReviewForm
from django.core.files.base import ContentFile
from django.http import JsonResponse
import re
from django.core.paginator import Paginator
# import logging
from .models import AdminNotification
from .decorators import seller_approved_required, guest_or_login_required
# ==================== SUPABASE CLIENT & HELPERS ====================

def get_supabase_client():
    return create_client(settings.SUPABASE_URL, settings.SUPABASE_SERVICE_ROLE_KEY)

def fetch_whatsapp_from_supabase(supa_user_id):
    """Retrieve WhatsApp number from Supabase Auth metadata"""
    try:
        supabase = get_supabase_client()
        # Fetch user directly by ID (efficient & reliable)
        user = supabase.auth.admin.get_user_by_id(supa_user_id).user
        if user and user.user_metadata:
            return user.user_metadata.get("whatsapp_number")
    except Exception as e:
        print(f"⚠️ Supabase WhatsApp fetch failed: {e}")
    return None

# store/views.py - 

def upload_avatar_to_supabase(user_id, avatar_file):
    """Upload avatar to Supabase Storage and return public URL"""
    if not avatar_file:
        return None
    try:
        from supabase import create_client
        from django.conf import settings
        import uuid, os
        
        supabase = create_client(settings.SUPABASE_URL, settings.SUPABASE_SERVICE_ROLE_KEY)
        
        # Generate unique filename
        ext = os.path.splitext(avatar_file.name)[1].lower()
        # Using 'avatars/' as a folder inside the bucket is fine
        filename = f"avatars/{user_id}_{uuid.uuid4().hex}{ext}"
        
        supabase.storage.from_("profile_pictures").upload(
            filename, 
            avatar_file.read(), 
            {"content-type": avatar_file.content_type, "cache-control": "3600"}
        )
        
        public_url = supabase.storage.from_("profile_pictures").get_public_url(filename)
        return public_url
    except Exception as e:
        print(f"⚠️ Avatar upload failed: {e}")
        return None

def get_supabase_client():
    return create_client(settings.SUPABASE_URL, settings.SUPABASE_SERVICE_ROLE_KEY or settings.SUPABASE_ANON_KEY)

def get_or_create_django_user(supabase_user):
    username = supabase_user.user_metadata.get("username", supabase_user.email.split("@")[0])
    django_user, created = User.objects.get_or_create(
        username=username, defaults={"email": supabase_user.email, "first_name": supabase_user.user_metadata.get("first_name", "")}
    )
    if created:
        django_user.set_unusable_password()
        django_user.save()
    return django_user, created

def store_supabase_session(req, session):
    req.session["supabase_session"] = {"access_token": session.access_token, "refresh_token": session.refresh_token, "user_id": session.user.id, "email": session.user.email}
    req.session.modified = True

def clear_supabase_session(req):
    req.session.pop("supabase_session", None)
    req.session.modified = True

def convert_decimals_to_floats(obj):
    if isinstance(obj, Decimal): return float(obj)
    elif isinstance(obj, dict): return {k: convert_decimals_to_floats(v) for k, v in obj.items()}
    elif isinstance(obj, (list, tuple)): return [convert_decimals_to_floats(i) for i in obj]
    return obj

# 🔹 PROF TABLE HELPERS
def get_supabase_prof(user_id):
    supabase = get_supabase_client()
    try: return supabase.table("prof").select("*").eq("id", str(user_id)).single().execute().data
    except Exception: return None

def update_supabase_prof(user_id, data):
    supabase = get_supabase_client()
    try: supabase.table("prof").update(data).eq("id", str(user_id)).execute(); return True
    except Exception: return False

@login_required
@seller_approved_required
def seller_dashboard(request):
    return render(request, 'store/seller_dashboard.html')


def get_cart_data(req):
    if not req.user.is_authenticated: return {"items": [], "total": 0, "count": 0, "cart_id": None}
    session_data = req.session.get("supabase_session")
    # ✅ FIXED: Added 'data' suffix and colon
    if not session_data: return {"items": [], "total": 0, "count": 0, "cart_id": None}
    
    auth_user_id = session_data.get("user_id")
    supabase = get_supabase_client()
    try:
        cart_resp = supabase.table("carts").select("id").eq("user_id", auth_user_id).execute()
        if not cart_resp.data or len(cart_resp.data) == 0:
            insert_resp = supabase.table("carts").insert({"user_id": auth_user_id}).execute()
            cart_id = insert_resp.data[0]["id"] if insert_resp.data else None
        else: cart_id = cart_resp.data[0]["id"]
        
        if not cart_id: return {"items": [], "total": 0, "count": 0, "cart_id": None}
        
        items_resp = supabase.table("cart_items").select("id, quantity, unit_price, product_id").eq("cart_id", cart_id).execute()
        items = items_resp.data or []
        if not items: return {"items": [], "total": 0, "count": 0, "cart_id": cart_id}
        
        product_ids = [i["product_id"] for i in items]
        products = Product.objects.filter(id__in=product_ids).values("id", "name", "price", "slug", "supabase_image_path", "image_url", "stock", "seller__store_name")
        products_map = {p["id"]: p for p in products}
        
        cart_items, total, count = [], 0, 0
        for item in items:
            prod = products_map.get(item["product_id"])
            if prod:
                subtotal = item["unit_price"] * item["quantity"]
                total += subtotal; count += item["quantity"]
                cart_items.append({
                    "id": item["id"], "product": prod, "quantity": item["quantity"], "unit_price": item["unit_price"], "subtotal": subtotal,
                    "get_image": (prod["supabase_image_path"] and f"{settings.SUPABASE_URL}/storage/v1/object/public/product-uploads/{prod['supabase_image_path']}") or prod["image_url"] or "https://via.placeholder.com/400?text=No+Image"
                })
        return {"items": cart_items, "total": total, "count": count, "cart_id": cart_id}
    except Exception as e:
        print(f"⚠️ Cart sync error: {e}")
        return {"items": [], "total": 0, "count": 0, "cart_id": None}

# ==================== DECORATORS ====================
def seller_required(view):
    def wrap(req, *a, **k):
        if not req.user.is_authenticated: return redirect("login")
        if req.user.is_superuser: return view(req, *a, **k)
        if not hasattr(req.user, "seller_profile"): return redirect("store:seller_signup")
        return view(req, *a, **k)
    return wrap

def superuser_required(view):
    def wrap(req, *a, **k):
        if not req.user.is_superuser:
            messages.error(req, "🚫 Admin access required.")
            return redirect("store:home")
        return view(req, *a, **k)
    return wrap

# ==================== AUTHENTICATION ====================
def register(req):
    if req.user.is_authenticated:
        return redirect("store:home")

    if req.method == "POST":
        form = CustomUserCreationForm(req.POST)

        if form.is_valid():
            supabase = get_supabase_client()

            email = form.cleaned_data["email"].strip().lower()
            password = form.cleaned_data["password1"]
            username = form.cleaned_data["username"]
            first_name = form.cleaned_data.get("first_name", "")
            last_name = form.cleaned_data.get("last_name", "")
            whatsapp = form.cleaned_data.get("whatsapp_number", "")
            country = form.cleaned_data.get("country")

            try:
                # ==================================================
                # 1. CREATE USER IN SUPABASE AUTH
                # ==================================================
                supabase_response = supabase.auth.sign_up({
                    "email": email,
                    "password": password,
                    "options": {
                        "data": {
                            "username": username,
                            "first_name": first_name,
                            "last_name": last_name,
                            "whatsapp_number": whatsapp,
                            "country": country,
                        }
                    }
                })

                supabase_user = supabase_response.user

                if not supabase_user:
                    messages.error(
                        req,
                        "❌ Could not create Supabase account."
                    )
                    return render(
                        req,
                        "store/register.html",
                        {"form": form}
                    )

                # ==================================================
                # 2. CREATE DJANGO USER
                # ==================================================
                user = form.save(commit=False)

                # The password is already hashed by UserCreationForm
                user.save()

                # ==================================================
                # 3. SAVE DJANGO USER PROFILE
                # ==================================================
                if hasattr(user, "user_profile"):
                    user.user_profile.country = country
                    user.user_profile.whatsapp_number = whatsapp
                    user.user_profile.save()

                # ==================================================
                # 4. CREATE/UPDATE SUPABASE PROFILE
                # ==================================================
                try:
                    supabase.table("prof").upsert({
                        "id": str(supabase_user.id),
                        "username": username,
                        "email": email,
                        "whatsapp_number": whatsapp,
                        "country_code": country if country else None,
                    }).execute()

                except Exception as profile_error:
                    print(
                        "⚠️ Supabase profile sync failed:",
                        profile_error
                    )

                # ==================================================
                # 5. AUTO LOGIN
                # ==================================================
                django_login(req, user)

                # Store Supabase session if available
                if supabase_response.session:
                    store_supabase_session(
                        req,
                        supabase_response.session
                    )

                messages.success(
                    req,
                    "🎉 Account created! Welcome to ShopVibe."
                )

                return redirect("store:home")

            except Exception as e:
                print(
                    f"🔴 REGISTRATION ERROR: "
                    f"{type(e).__name__}: {str(e)}"
                )

                messages.error(
                    req,
                    f"❌ Registration failed: {str(e)}"
                )

    else:
        form = CustomUserCreationForm()

    return render(
        req,
        "store/register.html",
        {"form": form}
    )

def login_view(req):
    """Login view with Supabase Auth - Minimal working version"""
    import logging
    logger = logging.getLogger(__name__)
    
    # Redirect if already logged in
    if req.user.is_authenticated:
        return redirect("store:admin_dashboard" if req.user.is_superuser else "store:home")
    
    if req.method == "POST":
        email = req.POST.get("email", "").strip().lower()
        password = req.POST.get("password", "")
        
        # Validate input
        if not email or not password:
            messages.error(req, "❌ Please enter both email and password.")
            return render(req, "store/login.html", {"email_value": email})
        
        try:
            # Initialize Supabase client
            supabase = get_supabase_client()
            
            # Sign in with Supabase Auth
            response = supabase.auth.sign_in_with_password({
                "email": email,
                "password": password
            })
            
            # Check if authentication succeeded
            if response.user:
                # Get or create Django user
                django_user, created = get_or_create_django_user(response.user)
                
                # Log into Django session
                django_login(req, django_user)
                
                # Store Supabase session if available
                if response.session:
                    store_supabase_session(req, response.session)
                
                # Success messages + redirect
                if django_user.is_superuser:
                    messages.success(req, f"👋 Welcome back, Admin {django_user.username}!")
                    return redirect("store:admin_dashboard")
                
                messages.success(req, f"👋 Welcome back, {django_user.first_name or django_user.username}!")
                return redirect("store:home")
            else:
                messages.error(req, "❌ Invalid email or password.")
                
        except Exception as e:
            # Log full error for debugging
            logger.exception(f"Login error: {type(e).__name__} - {str(e)}")
            
            # User-friendly error messages
            err_msg = str(e).lower()
            if "invalid login" in err_msg or "invalid credentials" in err_msg:
                messages.error(req, "❌ Invalid email or password.")
            elif "email not confirmed" in err_msg:
                messages.error(req, "⚠️ Please confirm your email address first.")
            elif "user not found" in err_msg:
                messages.error(req, "❌ No account found with this email.")
            else:
                messages.error(req, "❌ Login failed. Please try again.")
        
        # Re-render form with error
        return render(req, "store/login.html", {"email_value": email})
    
    # GET request - show login form
    return render(req, "store/login.html")

def logout_view(req):
    clear_supabase_session(req); django_logout(req); messages.success(req, "👋 Logged out successfully."); return redirect("store:home")

def oauth_callback(req): return redirect("store:home")

# ==================== STOREFRONT ====================

def home(req):
    q = req.GET.get("q", "").strip()
    cat_slug = req.GET.get("category")
    price_min = req.GET.get("price_min")
    price_max = req.GET.get("price_max")
    sort = req.GET.get("sort", "newest")

    categories = Category.objects.all().order_by('name')
    prods = Product.objects.filter(is_active=True, stock__gt=0)

    if q:
        prods = prods.filter(
            Q(name__icontains=q) |
            Q(description__icontains=q) |
            Q(category__name__icontains=q)
        )

    if cat_slug:
        prods = prods.filter(category__slug=cat_slug)

    if price_min:
        try:
            prods = prods.filter(price__gte=float(price_min))
        except (ValueError, TypeError):
            pass
    if price_max:
        try:
            prods = prods.filter(price__lte=float(price_max))
        except (ValueError, TypeError):
            pass

    if sort == "price_asc":
        prods = prods.order_by("price", "-created_at")
    elif sort == "price_desc":
        prods = prods.order_by("-price", "-created_at")
    elif sort == "name_asc":
        prods = prods.order_by("name", "-created_at")
    elif sort == "name_desc":
        prods = prods.order_by("-name", "-created_at")
    else:
        prods = prods.order_by("-created_at")

    paginator = Paginator(prods, 24)
    products = paginator.get_page(req.GET.get("page"))
    cart_count = len(req.session.get('cart', {})) if req.session else 0

    followed_updates = []
    if req.user.is_authenticated:
        followed_ids = list(
            SellerFollow.objects.filter(buyer=req.user).values_list('seller_id', flat=True)
        )
        if followed_ids:
            followed_updates = list(
                Product.objects.filter(seller_id__in=followed_ids, is_active=True)
                .select_related('seller')
                .order_by('-created_at')[:12]
            )

    return render(req, "store/home.html", {
        "products": products,
        "categories": categories,
        "cart_count": cart_count,
        "followed_updates": followed_updates,
        "current_filters": {
            "q": q, "category": cat_slug, "price_min": price_min,
            "price_max": price_max, "sort": sort,
        }
    })


def wishlist(req):
    """
    Wishlist page. Intentionally has no server-side wishlist logic —
    saved items live in the browser's localStorage (see the sv_wishlist
    key set up in base.html) and are rendered client-side by wishlist.html,
    which calls wishlist_products_api() below to fill in real product data.
    This view just serves the page shell.
    """
    cart_count = len(req.session.get('cart', {})) if req.session else 0
    return render(req, "store/wishlist.html", {"cart_count": cart_count})


def wishlist_products_api(req):
    """
    Read-only lookup: given ?ids=1,2,3 (the product IDs stored in the
    sv_wishlist localStorage key), return each product's current name,
    price, image, and slug so the wishlist page can render real cards
    and link to the actual product page.
    """
    ids_param = req.GET.get("ids", "")
    ids = [i for i in ids_param.split(",") if i.strip().isdigit()]
    if not ids:
        return JsonResponse({"products": []})

    products = Product.objects.filter(id__in=ids).values(
        "id", "name", "price", "slug", "supabase_image_path", "image_url", "is_active"
    )
    result = []
    for p in products:
        image = (
            (p["supabase_image_path"] and f"{settings.SUPABASE_URL}/storage/v1/object/public/product-uploads/{p['supabase_image_path']}")
            or p["image_url"]
            or ""
        )
        result.append({
            "id": p["id"],
            "name": p["name"],
            "price": str(p["price"]),
            "slug": p["slug"],
            "image": image,
            "is_active": p["is_active"],
        })
    return JsonResponse({"products": result})


@require_POST
def chatbot_recommend(req):
    """
    AI shopping-assistant endpoint. Takes a free-text description of what
    the customer wants and returns a short reply + matching products,
    picked only from real catalog data (never invented by the model).
    """
    try:
        body = json.loads(req.body.decode("utf-8"))
    except (json.JSONDecodeError, UnicodeDecodeError):
        return JsonResponse({"error": "Invalid request body"}, status=400)

    user_message = (body.get("message") or "").strip()
    history = body.get("history") or []

    if not user_message:
        return JsonResponse({"error": "message is required"}, status=400)

    if not OPENROUTER_API_KEY:
        return JsonResponse({"error": "Server not configured (missing OPENROUTER_API_KEY)"}, status=500)

    # Same base queryset convention as home() — active, in-stock products only
    prods = Product.objects.filter(is_active=True, stock__gt=0)[:200]

    catalog_lines = []
    id_to_product = {}
    for p in prods:
        id_to_product[p.id] = p
        catalog_lines.append(
            f"id={p.id} | {p.name} | category={p.category.name} "
            f"| price=GH₵{p.price} | stock={p.stock} | {p.description[:120]}"
        )
    catalog_text = "\n".join(catalog_lines)

    system_prompt = f"""You are a friendly shopping assistant for ShopVibe,
an online marketplace. A customer will describe what they're looking for.
Recommend ONLY items from the catalog below — never invent products or IDs.

CATALOG:
{catalog_text}

Respond with STRICT JSON only, no markdown, no extra text, in this exact shape:
{{
  "reply": "a short, friendly, 1-3 sentence response to the customer",
  "product_ids": [list of matching product ids from the catalog, empty if none fit]
}}
Pick at most 5 product_ids, ranked best match first."""

    messages = [{"role": "system", "content": system_prompt}]
    messages.extend(history[-6:])
    messages.append({"role": "user", "content": user_message})

    try:
        ai_resp = requests.post(
            OPENROUTER_URL,
            headers={
                "Authorization": f"Bearer {OPENROUTER_API_KEY}",
                "Content-Type": "application/json",
                "HTTP-Referer": "https://shopvibe.up.railway.app/",
                "X-Title": "ShopVibe Chatbot",
            },
            json={
                "model": OPENROUTER_MODEL,
                "messages": messages,
                "temperature": 0.4,
                "max_tokens": 400,
            },
            timeout=20,
        )
        ai_resp.raise_for_status()
        raw_content = ai_resp.json()["choices"][0]["message"]["content"]
    except requests.RequestException as e:
        return JsonResponse({"error": f"AI service error: {e}"}, status=502)

    cleaned = raw_content.strip().strip("`").replace("json\n", "", 1).strip()
    try:
        parsed = json.loads(cleaned)
    except json.JSONDecodeError:
        return JsonResponse({"reply": raw_content, "products": []})

    reply_text = parsed.get("reply", "")
    product_ids = parsed.get("product_ids", []) or []

    matched = [id_to_product[pid] for pid in product_ids if pid in id_to_product]
    products_json = [
        {
            "id": p.id,
            "name": p.name,
            "price": str(p.price),
            "image_url": p.get_image(),
            "slug": p.slug,
        }
        for p in matched
    ]

    return JsonResponse({"reply": reply_text, "products": products_json})


# NOTE: an earlier duplicate `product_detail` view (WhatsApp-based) lived here.
# Django uses the last definition of a name in a module, so that copy was
# always dead code — removed rather than left to bit-rot. The live
# implementation, further down, no longer exposes any WhatsApp number.


@login_required
def submit_review(req, product_id):
    """Handle review submission"""
    product = get_object_or_404(Product, id=product_id)
    
    if req.method == "POST":
        rating = req.POST.get("rating")
        comment = req.POST.get("comment", "").strip()
        
        if rating and comment:
            # ✅ Create and save review
            review = Review.objects.create(
                user=req.user,
                product=product,
                rating=int(rating),
                comment=comment,
                # ✅ If you have moderation, default to pending:
                # is_approved=False  # Uncomment if using moderation
            )
            messages.success(req, "✅ Review submitted! Thank you.")
            
            # ✅ CRITICAL: Redirect to force fresh context load
            return redirect("store:product_detail", slug=product.slug)
    
    return redirect("store:product_detail", slug=product.slug)

# ==================== CART & CHECKOUT ====================

# ==================== SHARED CART (simple shareable link) ====================

def _sync_own_db_cart(user, product, quantity=1, color='', size='', remove=False):
    """Keep the user's DB-backed cart in sync with their session cart so a
    shared link always shows their *current* cart."""
    try:
        cart = user.cart
    except Cart.DoesNotExist:
        return
    if remove or quantity < 1:
        CartItem.objects.filter(cart=cart, product=product, color=color or '', size=size or '').delete()
    else:
        CartItem.objects.update_or_create(
            cart=cart, product=product, color=color or '', size=size or '',
            defaults={'quantity': quantity, 'added_by': user})

def _drop_from_shared_carts(product):
    """Called after a purchase completes: quietly remove the product from
    every cart exposed via an active share link, so it disappears from the
    shared view — without revealing who bought it."""
    CartItem.objects.filter(
        cart__user__shared_cart_links__is_active=True, product=product
    ).delete()

@login_required
@require_POST
def share_cart(req):
    """Create (or reuse) the user's shareable cart link and return it for copying."""
    cart, _ = Cart.objects.get_or_create(user=req.user)
    # Make sure the DB cart reflects the session cart right now
    raw = req.session.get('cart', {})
    if isinstance(raw, dict):
        for raw_key, item_data in raw.items():
            try:
                pid, _, _ = _parse_cart_key(raw_key)
                product = Product.objects.get(id=int(pid), is_active=True)
                qty = item_data.get('quantity', 1) if isinstance(item_data, dict) else item_data
                qty = max(1, int(float(qty)))
                color = str(item_data.get('color', '') or '').strip() if isinstance(item_data, dict) else ''
                size = str(item_data.get('size', '') or '').strip() if isinstance(item_data, dict) else ''
                color, size = _normalise_variant(product, color, size)
                CartItem.objects.update_or_create(
                    cart=cart, product=product, color=color, size=size,
                    defaults={'quantity': qty, 'added_by': req.user})
            except (Product.DoesNotExist, ValueError, TypeError):
                continue
    link = req.user.shared_cart_links.filter(is_active=True).first() \
        or SharedCartLink.objects.create(owner=req.user)
    url = req.build_absolute_uri(reverse('store:shared_cart', args=[link.token]))
    if req.headers.get('x-requested-with') == 'XMLHttpRequest':
        return JsonResponse({'url': url})
    messages.success(req, f"🔗 Your shared cart link: {url}")
    return redirect('store:cart')

@require_POST
def start_shared_cart_purchase(req, token, action):
    """Put one item or the entire shared cart into the payer's checkout.
    action='gift'/'gift_all' means the shared-cart owner receives the order;
    action='self'/'self_all' means the person opening the link receives it.

    'self'/'self_all' requires an account (the order has to belong to
    someone), so only 'gift'/'gift_all' is open to anonymous guests."""
    link = get_object_or_404(SharedCartLink, token=token, is_active=True)

    is_all = action in ('gift_all', 'self_all')
    purchase_action = 'gift' if action in ('gift', 'gift_all') else 'self'

    if purchase_action == 'self' and not req.user.is_authenticated:
        messages.info(req, "🔐 Please log in to buy this for yourself.")
        return redirect('store:login')

    if is_all:
        items_qs = list(
            link.owner.cart.items.select_related('product').filter(
                product__is_active=True, is_shared=True)
        )
        if not items_qs:
            messages.error(req, 'This shared cart is empty.')
            return redirect('store:shared_cart', token=token)
        items = items_qs
    else:
        item_id = req.POST.get('item_id')
        # is_shared=True here too: a private item must not be purchasable even
        # if someone guesses or replays its id.
        item = get_object_or_404(
            CartItem.objects.select_related('product', 'cart__user'),
            id=item_id, cart__user=link.owner, product__is_active=True, is_shared=True
        )
        items = [item]

    return _stage_shared_purchase(
        req, link.owner, items, purchase_action, is_all,
        token=str(token),
        fallback_url=reverse('store:shared_cart', args=[token]),
    )


def _stage_shared_purchase(req, owner, items, purchase_action, is_all,
                           token=None, fallback_url=None):
    """Put the selected shared-cart items into the payer's checkout session."""
    # Validate stock before starting checkout so the payer does not reach
    # Paystack only to discover that one of the selected items is unavailable.
    for item in items:
        if item.product.stock < item.quantity:
            messages.error(
                req,
                f'Sorry, there is not enough stock available for {item.product.name}.'
            )
            return redirect(fallback_url or reverse('store:cart'))

    checkout_cart = {}
    source_item_ids = []
    for item in items:
        color, size = _normalise_variant(item.product, item.color, item.size)
        checkout_cart[_cart_key(item.product.id, color, size)] = {
            'quantity': item.quantity, 'color': color, 'size': size
        }
        source_item_ids.append(item.id)

    # A fresh checkout session prevents an existing buyer cart from being mixed
    # into a shared-cart purchase.
    req.session['cart'] = checkout_cart
    req.session['shared_purchase'] = {
        'owner_id': owner.id,
        'payer_id': req.user.id if req.user.is_authenticated else None,
        'action': purchase_action,
        'source_item_ids': source_item_ids,
        'source_item_id': source_item_ids[0] if len(source_item_ids) == 1 else None,
        'purchase_all': is_all,
        'token': token,
    }
    req.session.modified = True
    return redirect('store:checkout')


def shared_cart(req, token):
    """Anyone with the link can view the owner's current cart. Purchases are
    private: bought items simply vanish from this view."""
    link = get_object_or_404(SharedCartLink, token=token, is_active=True)
    items, total = [], Decimal('0.00')
    # Only items the owner has explicitly marked as shared are visible here —
    # the rest of their cart stays private.
    for ci in link.owner.cart.items.select_related('product').filter(is_shared=True):
        if not ci.product.is_active:
            continue
        subtotal = ci.product.price * Decimal(str(ci.quantity))
        total += subtotal
        items.append({'item': ci, 'subtotal': subtotal})
    return render(req, 'store/shared_cart.html',
                  {'link': link, 'items': items, 'total': total})

@login_required
@require_POST
def toggle_cart_item_shared(req):
    """Flip one of the user's own cart items between private and shared.

    The personal cart is the source of truth for what the user is buying; the
    shared cart shows only the subset they choose to expose. Accepts either a
    session cart key (`cart_key`) or a CartItem id (`item_id`)."""
    cart, _ = Cart.objects.get_or_create(user=req.user)
    item = None

    item_id = req.POST.get('item_id')
    if item_id:
        item = CartItem.objects.filter(cart=cart, id=item_id).first()
    else:
        cart_key = str(req.POST.get('cart_key') or '')
        try:
            pid, color, size = _parse_cart_key(cart_key)
            product = Product.objects.get(id=int(_parse_cart_key(pid)[0]))
            color, size = _normalise_variant(product, color, size)
            item, _ = CartItem.objects.get_or_create(
                cart=cart, product=product, color=color, size=size,
                defaults={'quantity': 1, 'added_by': req.user})
        except (Product.DoesNotExist, ValueError, TypeError):
            item = None

    if not item:
        return JsonResponse({'success': False, 'error': 'Item not in your cart.'}, status=404)

    raw = req.POST.get('is_shared')
    item.is_shared = (raw.lower() in ('1', 'true', 'on', 'yes')) if raw is not None else (not item.is_shared)
    item.save(update_fields=['is_shared'])

    if req.headers.get('x-requested-with') == 'XMLHttpRequest':
        return JsonResponse({'success': True, 'is_shared': item.is_shared})
    messages.success(
        req,
        '👀 Item added to your shared cart.' if item.is_shared
        else '🔒 Item hidden from your shared cart.')
    return redirect('store:cart')


def _visible_shared_item(req, item_id, token=None):
    """Fetch a shared cart item the requester is allowed to act on: either it
    is exposed through the share link `token`, or its owner is linked to the
    requester's account. Private items are never returned."""
    qs = CartItem.objects.select_related('product', 'cart__user').filter(
        id=item_id, is_shared=True, product__is_active=True)
    if token:
        link = SharedCartLink.objects.filter(token=token, is_active=True).first()
        if not link:
            return None
        return qs.filter(cart__user=link.owner).first()
    if not req.user.is_authenticated:
        return None
    owner_ids = [u.id for u in get_linked_users(req.user)]
    return qs.filter(cart__user_id__in=owner_ids).first()


@require_POST
def add_shared_item_to_cart(req, item_id):
    """Copy an item from someone's shared cart into the viewer's own cart."""
    token = req.POST.get('token') or None
    item = _visible_shared_item(req, item_id, token)
    if not item:
        messages.error(req, 'That item is no longer available.')
        return redirect(req.META.get('HTTP_REFERER') or reverse('store:cart'))

    product = item.product
    if product.stock <= 0:
        messages.warning(req, 'This product is out of stock.')
        return redirect(req.META.get('HTTP_REFERER') or reverse('store:cart'))

    color, size = _normalise_variant(product, item.color, item.size)
    cart = req.session.get('cart', {})
    if not isinstance(cart, dict):
        cart = {}
    key = _cart_key(product.id, color, size)
    existing = cart.get(key, {})
    current_qty = existing.get('quantity', 0) if isinstance(existing, dict) else existing
    try:
        current_qty = max(0, int(float(current_qty)))
    except (TypeError, ValueError):
        current_qty = 0
    new_qty = min(product.stock, current_qty + max(1, item.quantity))
    cart[key] = {'quantity': new_qty, 'color': color, 'size': size}
    req.session['cart'] = cart
    req.session.modified = True
    if req.user.is_authenticated:
        _sync_own_db_cart(req.user, product, new_qty, color, size)
    messages.success(req, f'✓ {product.name} added to your cart.')
    return redirect('store:cart')


@require_POST
def start_linked_cart_purchase(req, item_id, action):
    """Buy an item from a linked partner's shared cart — for them (a gift) or
    for yourself. Same flow as the share-link page, without a token."""
    purchase_action = 'gift' if action == 'gift' else 'self'
    if purchase_action == 'self' and not req.user.is_authenticated:
        messages.info(req, "🔐 Please log in to buy this for yourself.")
        return redirect('store:login')

    item = _visible_shared_item(req, item_id)
    if not item:
        messages.error(req, 'That item is no longer available.')
        return redirect(f"{reverse('store:cart')}?tab=shared")

    return _stage_shared_purchase(
        req, item.cart.user, [item], purchase_action, is_all=False,
        fallback_url=f"{reverse('store:cart')}?tab=shared",
    )


@login_required
@require_POST
def stop_sharing_cart(req):
    req.user.shared_cart_links.filter(is_active=True).update(is_active=False)
    messages.success(req, "🔒 Cart sharing turned off. Old links no longer work.")
    return redirect('store:cart')


# ==================== LINKED SHARED CARTS (accounts, not just links) ====================

def _active_links_for(user):
    """Accepted CartInvite rows where `user` is either side."""
    return CartInvite.objects.filter(
        Q(inviter=user) | Q(invitee=user), status='accepted'
    ).select_related('inviter', 'invitee')

def get_linked_users(user):
    """Every account currently linked (accepted) to this user's cart."""
    linked = []
    for link in _active_links_for(user):
        other = link.other_party(user)
        if other:
            linked.append(other)
    return linked

def _accept_cart_invite(invite, user):
    """Shared accept logic used by the in-app Accept button and the emailed link."""
    if invite.invitee_id and invite.invitee_id != user.id:
        return False
    invite.invitee = user
    invite.status = 'accepted'
    invite.responded_at = timezone.now()
    invite.save(update_fields=['invitee', 'status', 'responded_at'])
    UserNotification.objects.create(
        user=invite.inviter, title='Cart link accepted',
        message=f"{user.username} accepted your cart link invitation.",
        link=reverse('store:cart'),
    )
    return True

@login_required
@require_POST
def invite_to_cart(req):
    """Send a 'Linked Shared Carts' invitation — by username (if they already
    have an account) or by email (if they don't yet). Either way an email
    with an accept link is sent, since the account-based invitee may not
    check in-app notifications."""
    identifier = (req.POST.get('identifier') or '').strip()
    relation = req.POST.get('relation') or 'other'
    if relation not in dict(CartInvite.RELATION_CHOICES):
        relation = 'other'
    if not identifier:
        return JsonResponse({'success': False, 'error': 'Enter a username or email address.'}, status=400)

    target = User.objects.filter(Q(username__iexact=identifier) | Q(email__iexact=identifier)).exclude(id=req.user.id).first()
    if not target and '@' not in identifier:
        return JsonResponse({'success': False, 'error': "We couldn't find that account."}, status=404)

    recipient_email = target.email if target else identifier
    if not recipient_email:
        return JsonResponse({'success': False, 'error': 'That account has no email address on file.'}, status=400)

    # Already linked or already invited (either direction)?
    existing = CartInvite.objects.filter(
        Q(inviter=req.user, invitee=target) | Q(inviter=target, invitee=req.user)
    ).filter(status__in=['pending', 'accepted']).first() if target else None
    if existing:
        if existing.status == 'accepted':
            return JsonResponse({'success': False, 'error': 'That account is already linked to your cart.'}, status=400)
        return JsonResponse({'success': False, 'error': 'An invitation is already pending with that account.'}, status=400)

    invite = CartInvite.objects.create(
        inviter=req.user, invitee=target,
        invited_email='' if target else identifier,
        relation=relation,
    )

    accept_url = req.build_absolute_uri(reverse('store:accept_invite_via_email', args=[invite.token]))
    try:
        send_mail(
            subject=f"{req.user.username} wants to link shopping carts with you on ShopVibe",
            message=(
                f"{req.user.username} invited you to link carts as their {invite.get_relation_display()} "
                f"on ShopVibe, for live collaborative shopping.\n\n"
                f"Accept the invitation here: {accept_url}\n\n"
                f"If you weren't expecting this, you can ignore this email."
            ),
            from_email=None,
            recipient_list=[recipient_email],
            fail_silently=False,
        )
    except Exception:
        invite.delete()
        return JsonResponse({'success': False, 'error': 'Could not send the invite email right now. Please try again later.'}, status=502)

    if target:
        UserNotification.objects.create(
            user=target, title='Cart link invitation',
            message=f"{req.user.username} wants to link carts with you ({invite.get_relation_display()}).",
            link=reverse('store:cart'),
        )
    return JsonResponse({'success': True, 'invite': {
        'id': invite.id,
        'name': target.username if target else invite.invited_email,
        'relation': invite.get_relation_display(),
        'status': invite.status,
    }})

@login_required
@require_POST
def respond_cart_invite(req, invite_id, action):
    invite = get_object_or_404(CartInvite, id=invite_id, invitee=req.user, status='pending')
    if action not in ('accept', 'decline'):
        return JsonResponse({'success': False, 'error': 'Invalid action.'}, status=400)
    if action == 'accept':
        _accept_cart_invite(invite, req.user)
    else:
        invite.status = 'declined'
        invite.responded_at = timezone.now()
        invite.save(update_fields=['status', 'responded_at'])
    UserNotification.objects.create(
        user=invite.inviter, title='Cart link ' + ('accepted' if action == 'accept' else 'declined'),
        message=f"{req.user.username} {'accepted' if action == 'accept' else 'declined'} your cart link invitation.",
        link=reverse('store:cart'),
    )
    return JsonResponse({'success': True, 'status': invite.status})

@login_required
@require_POST
def cancel_cart_invite(req, invite_id):
    """Cancel a pending invite you sent, or unlink an already-accepted account."""
    invite = get_object_or_404(
        CartInvite.objects.filter(Q(inviter=req.user) | Q(invitee=req.user)), id=invite_id
    )
    invite.delete()
    return JsonResponse({'success': True})

def accept_invite_via_email(req, token):
    """Landing page for the link emailed to an invitee. If they're logged in
    already, accept immediately; otherwise stash the token and finish the
    job the next time they load the cart (right after login/register)."""
    invite = get_object_or_404(CartInvite, token=token, status='pending')
    if req.user.is_authenticated:
        if _accept_cart_invite(invite, req.user):
            messages.success(req, f"🔗 You're now linked with {invite.inviter.username}'s cart.")
        else:
            messages.error(req, "This invitation was meant for a different account.")
        return redirect(f"{reverse('store:cart')}?tab=shared")
    req.session['pending_cart_invite_token'] = str(invite.token)
    req.session.modified = True
    messages.info(req, "Please log in or create an account to accept this cart link invitation.")
    return redirect('store:login')

def _cart_key(product_id, color='', size=''):
    return f"{product_id}::{str(color or '').strip()}::{str(size or '').strip()}"

def _parse_cart_key(key):
    text = str(key)
    if '::' in text:
        parts = text.split('::', 2)
        return parts[0], parts[1], parts[2]
    return text, '', ''

def _normalise_variant(product, color='', size=''):
    color = str(color or '').strip()
    size = str(size or '').strip()
    if product.get_colors() and color not in product.get_colors(): color = ''
    if product.size_list and size not in product.size_list: size = ''
    return color, size

@require_POST
def add_to_cart(req, product_id):
    # Adding to cart mutates the session (and the shared cart in the DB), so
    # this must be POST-only. It used to also accept GET via a plain <a
    # href> link — but a GET here isn't just semantically wrong, it also
    # means any speculative prefetch of that link (e.g. Chrome's "preload
    # pages" hover-prefetch, link-preview bots, etc.) silently adds the item
    # to the cart before the user even clicks, so the real click on top of
    # that made quantity land on 2 instead of 1.
    product = get_object_or_404(Product, id=product_id, is_active=True)
    if product.stock <= 0:
        messages.warning(req, 'This product is out of stock.')
        return redirect('store:product_detail', slug=product.slug)

    data = req.POST
    color, size = _normalise_variant(product, data.get('color'), data.get('size'))
    missing = []
    if product.get_colors() and not color: missing.append('color')
    if product.size_list and not size: missing.append('size')
    if missing:
        messages.warning(req, 'Please select ' + ' and '.join(missing) + ' before adding this product to your cart.')
        return redirect('store:product_detail', slug=product.slug)

    cart = req.session.get('cart', {})
    if not isinstance(cart, dict): cart = {}
    key = _cart_key(product.id, color, size)
    existing = cart.get(key, {})
    current_qty = existing.get('quantity', 0) if isinstance(existing, dict) else existing
    try: current_qty = max(0, int(float(current_qty)))
    except (TypeError, ValueError): current_qty = 0
    new_qty = min(product.stock, current_qty + 1)
    cart[key] = {'quantity': new_qty, 'color': color, 'size': size}
    req.session['cart'] = cart
    req.session.modified = True
    if req.user.is_authenticated:
        _sync_own_db_cart(req.user, product, new_qty, color, size)
    messages.success(req, f'✓ {product.name} added to your cart.')
    return redirect('store:cart')


@login_required
def cart(req):
    raw_cart = req.session.get('cart', {})
    if not isinstance(raw_cart, dict): raw_cart = {}
    cart_items, cart_total, cart_count, clean_cart = [], Decimal('0.00'), 0, {}

    for raw_key, item_data in raw_cart.items():
        try:
            pid, key_color, key_size = _parse_cart_key(raw_key)
            product = Product.objects.get(id=int(_parse_cart_key(pid)[0]), is_active=True)
            color, size = key_color, key_size
            quantity = item_data.get('quantity', 1) if isinstance(item_data, dict) else item_data
            if isinstance(item_data, dict):
                color = str(item_data.get('color', color) or color).strip()
                size = str(item_data.get('size', size) or size).strip()
            while isinstance(quantity, dict): quantity = quantity.get('quantity', 1)
            quantity = max(1, int(float(quantity)))
            color, size = _normalise_variant(product, color, size)
            key = _cart_key(product.id, color, size)
            subtotal = product.price * Decimal(str(quantity))
            cart_items.append({'key': key, 'product': product, 'quantity': quantity, 'color_variant': color, 'size_variant': size, 'total_price': subtotal})
            cart_total += subtotal; cart_count += quantity
            clean_cart[key] = {'quantity': quantity, 'color': color, 'size': size}
        except (Product.DoesNotExist, ValueError, TypeError):
            continue

    if clean_cart != raw_cart:
        req.session['cart'] = clean_cart; req.session.modified = True

    # The session cart drives this page, but the shared/private flag lives on
    # the DB CartItem — map one onto the other by variant key.
    shared_flags = {}
    try:
        for ci in req.user.cart.items.select_related('product'):
            shared_flags[_cart_key(ci.product_id, ci.color, ci.size)] = ci.is_shared
    except Cart.DoesNotExist:
        pass
    for entry in cart_items:
        entry['is_shared'] = shared_flags.get(entry['key'], False)

    link = req.user.shared_cart_links.filter(is_active=True).first()
    share_url = (req.build_absolute_uri(reverse('store:shared_cart', args=[link.token]))
                 if link else None)

    # ---- Linked Shared Carts ----
    pending_token = req.session.pop('pending_cart_invite_token', None)
    if pending_token:
        req.session.modified = True
        pending_invite = CartInvite.objects.filter(token=pending_token, status='pending').first()
        if pending_invite and _accept_cart_invite(pending_invite, req.user):
            messages.success(req, f"🔗 You're now linked with {pending_invite.inviter.username}'s cart.")

    active_invites = list(_active_links_for(req.user)) if req.user.is_authenticated else []
    pending_sent = list(CartInvite.objects.filter(inviter=req.user, status='pending')) if req.user.is_authenticated else []
    pending_received = list(CartInvite.objects.filter(invitee=req.user, status='pending')) if req.user.is_authenticated else []

    active_links = []
    shared_items, shared_total, shared_count = [], Decimal('0.00'), 0
    for invite in active_invites:
        other = invite.other_party(req.user)
        if not other:
            continue
        active_links.append({'invite': invite, 'user': other, 'relation': invite.get_relation_display()})
        try:
            other_cart = other.cart
        except Cart.DoesNotExist:
            continue
        for ci in other_cart.items.select_related('product').filter(product__is_active=True, is_shared=True):
            subtotal = ci.product.price * Decimal(str(ci.quantity))
            shared_items.append({'item': ci, 'owner': other, 'relation': invite.get_relation_display(), 'subtotal': subtotal})
            shared_total += subtotal
            shared_count += ci.quantity

    return render(req, 'store/cart.html', {
        'cart_items': cart_items, 'cart_total': cart_total, 'cart_count': cart_count,
        'share_url': share_url,
        'active_links': active_links,
        'pending_sent': pending_sent,
        'pending_received': pending_received,
        'shared_items': shared_items, 'shared_total': shared_total, 'shared_count': shared_count,
        'relation_choices': CartInvite.RELATION_CHOICES,
    })


def cart_view(req):
    raw_cart = req.session.get('cart', {})

    if not isinstance(raw_cart, dict):
        raw_cart = {}

    cart_items = []
    total = Decimal("0.00")
    count = 0
    clean_cart = {}

    for pid, item_data in raw_cart.items():

        try:
            product = Product.objects.get(id=pid)

            qty = 1
            color = ''

            # Handle dictionary cart item
            if isinstance(item_data, dict):

                qty = item_data.get('quantity', 1)
                color = item_data.get('color', '')

            # Handle old integer-based carts
            elif isinstance(item_data, (int, float, str)):

                qty = item_data

            # Flatten nested quantity dictionaries safely
            max_depth = 5

            while isinstance(qty, dict) and max_depth > 0:

                qty = qty.get('quantity') or qty.get('qty') or 1

                max_depth -= 1

            # Final safety check
            if isinstance(qty, dict):
                qty = 1

            try:
                qty = int(float(qty))

                if qty < 1:
                    qty = 1

            except (ValueError, TypeError):
                qty = 1

            # Safe Decimal multiplication
            item_total = Decimal(product.price) * Decimal(qty)

            total += item_total
            count += qty

            cart_items.append({
                'product': product,
                'quantity': qty,
                'color_variant': color,
                'total_price': item_total,
            })

            # Save cleaned structure
            clean_cart[str(pid)] = {
                'quantity': qty,
                'color': color,
            }

        except Product.DoesNotExist:
            continue

        except Exception as e:
            print("Cart Error:", e)
            continue

    # Auto-clean malformed cart session
    if clean_cart != raw_cart:

        req.session['cart'] = clean_cart
        req.session.modified = True

    return render(req, 'store/cart.html', {
        'cart_items': cart_items,
        'cart_total': total,
        'cart_count': count,
    })

def update_cart(req):
    if req.method != 'POST': return JsonResponse({'success': False, 'error': 'Invalid method'}, status=405)
    try:
        data = json.loads(req.body)
        with transaction.atomic():
            old_key = str(data.get('cart_key') or '')
            pid, old_color, old_size = _parse_cart_key(old_key)
            product = Product.objects.select_for_update().get(id=int(_parse_cart_key(pid)[0]), is_active=True)
            cart = req.session.get('cart', {})
            if not isinstance(cart, dict) or old_key not in cart:
                return JsonResponse({'success': False, 'error': 'Item not in cart'})
            item = cart[old_key] if isinstance(cart[old_key], dict) else {'quantity': cart[old_key]}
            try: current_qty = max(1, int(float(item.get('quantity', 1))))
            except (TypeError, ValueError): current_qty = 1
            if data.get('change') == 'remove':
                del cart[old_key]
                _sync_own_db_cart(req.user, product, 0, old_color, old_size, remove=True)
            else:
                try: new_qty = max(1, min(product.stock, current_qty + int(data.get('change', 0))))
                except (TypeError, ValueError): new_qty = current_qty
                color, size = _normalise_variant(product, data.get('color', old_color), data.get('size', old_size))
                if product.get_colors() and not color: return JsonResponse({'success': False, 'error': 'Please select a color.'})
                if product.size_list and not size: return JsonResponse({'success': False, 'error': 'Please select a size.'})
                new_key = _cart_key(product.id, color, size)
                if new_key != old_key:
                    del cart[old_key]
                    existing = cart.get(new_key, {})
                    existing_qty = existing.get('quantity', 0) if isinstance(existing, dict) else existing
                    try: existing_qty = max(0, int(float(existing_qty)))
                    except (TypeError, ValueError): existing_qty = 0
                    new_qty = min(product.stock, new_qty + existing_qty)
                    _sync_own_db_cart(req.user, product, 0, old_color, old_size, remove=True)
                cart[new_key] = {'quantity': new_qty, 'color': color, 'size': size}
                _sync_own_db_cart(req.user, product, new_qty, color, size)
            req.session['cart'] = cart; req.session.modified = True
            count = sum(int(v.get('quantity', 1)) if isinstance(v, dict) else int(v) for v in cart.values())
            return JsonResponse({'success': True, 'count': count})
    except Product.DoesNotExist:
        return JsonResponse({'success': False, 'error': 'Product not found.'}, status=404)
    except Exception as e:
        return JsonResponse({'success': False, 'error': str(e)}, status=400)

# store/views.py

logger = logging.getLogger(__name__)

@guest_or_login_required
def checkout(req):
    """Display checkout page with Paystack integration"""

    # An invoice checkout is priced by the seller's agreed figures, not by the
    # product's listed price.
    invoice = _active_invoice(req)
    if invoice:
        items = [{
            'product': invoice.product,
            'qty': invoice.quantity,
            'color': invoice.color,
            'size': invoice.size,
            'unit_price': invoice.unit_price,
            'subtotal': invoice.items_total,
        }]
        return render(req, "store/checkout.html", {
            "items": items,
            "subtotal": invoice.items_total,
            "delivery_fee": invoice.delivery_fee,
            "total": invoice.total,
            "total_kobo": int(invoice.total * 100),
            "paystack_public_key": settings.PAYSTACK_PUBLIC_KEY,
            "cart_count": 1,
            "cart_json": json.dumps({}),
            "site_url": settings.SITE_URL,
            "shared_purchase": None,
            "gift_recipient": None,
            "invoice": invoice,
        })

    cart_data = req.session.get('cart', {})
    
    if not isinstance(cart_data, dict):
        cart_data = {}
    
    if not cart_data:
        messages.warning(req, "🛒 Your cart is empty.")
        return redirect("store:cart") if req.user.is_authenticated else redirect("store:home")
    
    items = []
    total = Decimal('0.00')
    clean_cart = {}
    
    for pid, item_data in cart_data.items():
        try:
            product = Product.objects.get(id=int(_parse_cart_key(pid)[0]))
            
            quantity = 1
            color = ''
            size = ''
            
            # Handle dictionary structure
            if isinstance(item_data, dict):
                quantity = item_data.get('quantity', 1)
                color = item_data.get('color', '')
                size = item_data.get('size', '')
            # Handle old integer structure
            elif isinstance(item_data, (int, float)):
                quantity = item_data
            
            # Flatten nested dictionaries
            while isinstance(quantity, dict):
                quantity = quantity.get('quantity', 1)
            
            # Safe integer conversion
            try:
                quantity = int(quantity)
                if quantity < 1:
                    quantity = 1
            except (ValueError, TypeError):
                quantity = 1
            
            color, size = _normalise_variant(product, color, size)
            # Safe subtotal calculation
            subtotal = product.price * Decimal(str(quantity))
            
            items.append({
                "product": product,
                "qty": quantity,
                "color": color,
                "size": size,
                "subtotal": subtotal
            })
            
            total += subtotal
            
            # Save cleaned structure
            clean_cart[_cart_key(product.id, color, size)] = {
                "quantity": quantity,
                "color": color,
                "size": size
            }
            
        except Product.DoesNotExist:
            logger.warning(f"Product {pid} not found during checkout")
            continue
        except Exception as e:
            logger.error(f"Checkout error processing item {pid}: {e}")
            continue
    
    # Auto-fix corrupted cart data
    if clean_cart != cart_data:
        req.session['cart'] = clean_cart
        req.session.modified = True
    
    # Convert to pesewas/kobo for Paystack
    total_kobo = int(total * 100)
    
    # Prepare cart JSON for JavaScript (safe serialization)
    import json
    cart_json = json.dumps(clean_cart, default=str)
    
    shared_purchase = req.session.get('shared_purchase')
    gift_recipient = None
    if isinstance(shared_purchase, dict) and shared_purchase.get('action') == 'gift':
        gift_recipient = User.objects.filter(id=shared_purchase.get('owner_id')).first()

    return render(req, "store/checkout.html", {
        "items": items,
        "total": total,
        "subtotal": total,
        "delivery_fee": Decimal('0.00'),
        "invoice": None,
        "total_kobo": total_kobo,
        "paystack_public_key": settings.PAYSTACK_PUBLIC_KEY,
        "cart_count": len(items),
        "cart_json": cart_json,
        "site_url": settings.SITE_URL,
        "shared_purchase": shared_purchase,
        "gift_recipient": gift_recipient,
    })


@guest_or_login_required
@require_POST
def initialize_paystack_payment(req):
    """Initialize Paystack payment for cart checkout"""
    logger = logging.getLogger(__name__)
    
    try:
        is_guest = not req.user.is_authenticated
        guest_email = ''
        if is_guest:
            # guest_or_login_required already guarantees this is a
            # shared-cart 'gift' purchase; a guest still needs to supply an
            # email for Paystack to send the transaction to.
            try:
                body = json.loads(req.body or '{}')
            except (ValueError, TypeError):
                body = {}
            guest_email = str(body.get('email', '')).strip()
            if not guest_email or '@' not in guest_email:
                return JsonResponse({'error': 'Please enter a valid email address to continue.'}, status=400)

        # 1️⃣ Validate cart exists and has items
        invoice = _active_invoice(req)
        cart_data = req.session.get('cart', {})
        if not invoice and (not cart_data or not isinstance(cart_data, dict)):
            return JsonResponse({'error': 'Cart is empty or invalid'}, status=400)

        # 2️⃣ Calculate total amount safely (handle nested dict cart format)
        total = Decimal('0')
        valid_items = 0

        if invoice:
            # The negotiated price wins over the listed price, and the agreed
            # delivery fee is charged on top.
            if invoice.product.stock < invoice.quantity:
                return JsonResponse({'error': 'This item is no longer in stock.'}, status=400)
            total = invoice.total
            valid_items = 1
        else:
            with transaction.atomic():
                for pid, item in cart_data.items():
                    try:
                        # Extract quantity (handle both simple and nested dict formats)
                        if isinstance(item, dict):
                            qty = item.get('quantity', 1)
                            # Handle deeply nested dicts (defensive programming)
                            while isinstance(qty, dict):
                                qty = qty.get('quantity', 1)
                            qty = max(1, int(float(qty)))
                        else:
                            qty = max(1, int(float(item)))
                    
                        # Fetch product and validate
                        product = Product.objects.select_for_update().get(id=int(_parse_cart_key(pid)[0]), is_active=True)
                        total += product.price * Decimal(qty)
                        valid_items += 1
                    
                    except Product.DoesNotExist:
                        logger.warning(f"Product {pid} not found or inactive, skipping")
                        continue
                    except (ValueError, TypeError) as e:
                        logger.warning(f"Invalid quantity for product {pid}: {e}")
                        continue
        
        # Validate we have valid items and positive total
        if valid_items == 0 or total <= 0:
            return JsonResponse({'error': 'No valid items in cart'}, status=400)

        # 2b̲⃣ Community Highlights voucher, if the buyer applied one.
        #    The discount comes off the amount Paystack actually charges, so
        #    the Order total written on verification is already correct.
        voucher_code = req.session.get('applied_voucher')
        voucher_discount = Decimal('0')
        if voucher_code and req.user.is_authenticated:
            voucher = DiscountVoucher.objects.filter(
                code=voucher_code, buyer=req.user, is_used=False
            ).first()
            if voucher and voucher.is_redeemable:
                voucher_discount = voucher.discount_for(total)
                total = max(Decimal('1.00'), total - voucher_discount)
            else:
                req.session.pop('applied_voucher', None)
        
        # 3️⃣ Generate unique reference (timestamp + user ID for uniqueness)
        payer_ref_part = req.user.id if req.user.is_authenticated else 'guest'
        reference = f"SV-{payer_ref_part}-{int(timezone.now().timestamp())}-{valid_items}"
        shared_purchase = req.session.get('shared_purchase')
        gift_recipient = None
        if isinstance(shared_purchase, dict) and shared_purchase.get('action') == 'gift':
            gift_recipient = User.objects.filter(id=shared_purchase.get('owner_id')).first()
            if not gift_recipient:
                req.session.pop('shared_purchase', None)
                return JsonResponse({'error': 'The shared-cart recipient is no longer available.'}, status=400)
        
        # 4️⃣ Build Paystack payload with ALL required fields
        payload = {
            'email': guest_email if is_guest else (req.user.email or 'customer@shopvibe.com'),
            'amount': int(total * 100),  # ✅ Convert GH₵ to kobo (integer)
            'reference': reference,
            'callback_url': f"{settings.SITE_URL.rstrip('/')}/checkout/callback/",  # ✅ Use SITE_URL
            'metadata': {
                'user_id': req.user.id if req.user.is_authenticated else None,
                'username': req.user.username if req.user.is_authenticated else 'Guest',
                'items_count': valid_items,
                'cart_total_ghs': str(total),
                'shared_purchase': bool(shared_purchase),
                'recipient_user_id': gift_recipient.id if gift_recipient else req.user.id,
                'recipient_username': gift_recipient.username if gift_recipient else req.user.username,
                'purchase_type': 'gift' if gift_recipient else 'self',
                'invoice_id': invoice.id if invoice else None,
                'delivery_fee_ghs': str(invoice.delivery_fee) if invoice else '0.00',
            },
            'currency': 'GHS',  # ✅ Explicitly set currency for Ghana
        }
        
        # 5️⃣ Prepare headers with Paystack secret key
        headers = {
            'Authorization': f'Bearer {settings.PAYSTACK_SECRET_KEY}',
            'Content-Type': 'application/json',
            'User-Agent': 'ShopVibe/1.0',  # Optional but recommended
        }
        
        # 6️⃣ Log request for debugging (remove sensitive data in production)
        logger.info(f"Paystack init: user={req.user.id}, amount_kobo={payload['amount']}, ref={reference}")
        
        # 7️⃣ Call Paystack API with timeout and error handling
        resp = requests.post(
            'https://api.paystack.co/transaction/initialize',
            json=payload,
            headers=headers,
            timeout=15  # ✅ 15 second timeout to prevent hanging
        )
        
        # 8️⃣ Handle Paystack 400 errors with detailed logging
        if resp.status_code == 400:
            try:
                error_data = resp.json()
                logger.error(f"Paystack 400 Bad Request: {error_data}")
                return JsonResponse({
                    'error': error_data.get('message', 'Invalid payment request'),
                    'details': error_data.get('errors', []),
                    'reference': reference  # Return ref for debugging
                }, status=400)
            except Exception as parse_err:
                logger.error(f"Failed to parse Paystack 400 response: {parse_err}")
                logger.error(f"Raw response: {resp.text[:300]}")
        
        # 9️⃣ Raise for other HTTP errors (401, 403, 500, etc.)
        resp.raise_for_status()
        
        # 🔟 Parse successful response
        data = resp.json()
        
        if data.get('status') and data.get('data', {}).get('authorization_url'):
            # Save reference to session for verification callback
            req.session['paystack_ref'] = reference
            req.session['paystack_amount'] = str(total)  # Store for verification
            req.session.modified = True
            
            logger.info(f"Paystack success: auth_url={data['data']['authorization_url'][:50]}...")
            
            return JsonResponse({
                'success': True,
                'authorization_url': data['data']['authorization_url'],
                'reference': reference,
                'amount_ghs': str(total),
                # Authoritative amount, already net of any applied voucher.
                # The checkout popup must use this, not its own page-rendered
                # figure, or a discounted order would still charge full price.
                'amount_kobo': int(total * 100),
                'voucher_discount_ghs': str(voucher_discount),
            })
        else:
            logger.error(f"Paystack init failed: {data}")
            return JsonResponse({
                'error': data.get('message', 'Payment initialization failed')
            }, status=400)
            
    # 🔻 Comprehensive error handling
    except requests.exceptions.Timeout:
        logger.error("Paystack request timed out after 15s")
        return JsonResponse({'error': 'Payment service timeout. Please try again.'}, status=503)
        
    except requests.exceptions.SSLError as e:
        logger.error(f"Paystack SSL error: {e}")
        return JsonResponse({'error': 'Secure connection failed'}, status=503)
        
    except requests.exceptions.ConnectionError as e:
        logger.error(f"Paystack connection error: {e}")
        return JsonResponse({'error': 'Cannot connect to payment gateway'}, status=503)
        
    except requests.exceptions.HTTPError as e:
        if e.response is not None:
            logger.error(f"Paystack HTTP {e.response.status_code}: {e.response.text[:200]}")
        return JsonResponse({'error': 'Payment service unavailable'}, status=503)
        
    except requests.exceptions.RequestException as e:
        logger.exception(f"Paystack request exception: {e}")
        return JsonResponse({'error': 'Payment service error'}, status=503)
        
    except Product.DoesNotExist as e:
        logger.error(f"Product validation error: {e}")
        return JsonResponse({'error': 'Invalid product in cart'}, status=400)
        
    except Exception as e:
        logger.exception(f"Unexpected error in initialize_paystack_payment: {e}")
        return JsonResponse({'error': 'An unexpected error occurred'}, status=500)


logger = logging.getLogger(__name__)
@login_required
def paystack_callback(req):
    """Handle Paystack payment webhook/callback"""
    reference = req.GET.get('reference')
    if not reference:
        logger.warning("Callback without reference")
        return JsonResponse({'success': False, 'error': 'No payment reference'}, status=400)

    # 1️⃣ Check for existing order (Idempotency check)
    existing_order = Order.objects.filter(reference=reference).first()
    if existing_order:
        logger.info(f"Order for reference {reference} already processed.")
        return JsonResponse({
            'success': True,
            'order_id': existing_order.id,
            'message': 'Order already processed'
        })

    try:
        # Verify payment with Paystack
        verify_url = f"https://api.paystack.co/transaction/verify/{reference}"
        headers = {
            "Authorization": f"Bearer {settings.PAYSTACK_SECRET_KEY}",
            "Content-Type": "application/json",
        }
        
        response = requests.get(verify_url, headers=headers, timeout=30)
        response.raise_for_status()
        
        data = response.json()
        if not (data.get('status') and data.get('data', {}).get('status') == 'success'):
            logger.warning(f"Payment not successful: {reference}")
            return JsonResponse({
                'success': False,
                'error': 'Payment not completed or cancelled',
                'status': data.get('data', {}).get('status', 'unknown')
            }, status=400)

        paystack_data = data['data']
        paid_amount_ghs = Decimal(paystack_data['amount']) / Decimal('100')
        cart_data = req.session.get('cart', {})

        # 2️⃣ Process Order creation and Stock updates atomically
        with transaction.atomic():
            # Second check inside atomic block to prevent concurrent race conditions
            if Order.objects.filter(reference=reference).exists():
                return JsonResponse({'success': True, 'message': 'Order already exists'})

            shared_purchase = req.session.get('shared_purchase')
            gift_recipient = None
            if isinstance(shared_purchase, dict) and shared_purchase.get('action') == 'gift':
                gift_recipient = User.objects.filter(id=shared_purchase.get('owner_id')).first()

            order = Order.objects.create(
                user=gift_recipient or req.user,
                paid_by=req.user,
                reference=reference,
                total_amount=paid_amount_ghs,
                payment_status='paid',
                payment_method='paystack',
                paystack_response=paystack_data,
                customer_email=paystack_data.get('customer', {}).get('email', getattr(req.user, 'email', '')),
            )

            # An invoice purchase is priced by the seller's quote, so it does
            # not go through the cart pricing below.
            invoice = _active_invoice(req)
            if invoice:
                _record_invoice_order(req, order, invoice, paid_amount_ghs)
                req.session['cart'] = {}
                req.session.pop('invoice_checkout', None)
                req.session.pop('paystack_ref', None)
                req.session.pop('paystack_amount', None)
                req.session.modified = True
                return JsonResponse({'success': True, 'order_id': order.id,
                                     'message': 'Payment successful'})

            # Burn the Community Highlights voucher, if one was applied.
            _consume_applied_voucher(req, order)

            total_calculated = Decimal('0')
            items_processed = 0

            for pid, item in cart_data.items():
                try:
                    qty = item.get('quantity', 1) if isinstance(item, dict) else item
                    while isinstance(qty, dict):
                        qty = qty.get('quantity', 1)
                    qty = max(1, int(float(qty)))

                    # Lock row for stock update
                    product = Product.objects.select_for_update().get(id=int(_parse_cart_key(pid)[0]), is_active=True)
                    
                    actual_qty = min(product.stock, qty)
                    if actual_qty > 0:
                        product.stock -= actual_qty
                        product.save(update_fields=['stock'])

                        line_total = product.price * Decimal(actual_qty)
                        OrderItem.objects.create(
                            order=order,
                            product=product,
                            quantity=actual_qty,
                            price=product.price,
                            subtotal=line_total,
                            color=item.get('color', '') if isinstance(item, dict) else '',
                            size=item.get('size', '') if isinstance(item, dict) else '',
                        )
                        total_calculated += line_total
                        items_processed += 1

                except Product.DoesNotExist:
                    logger.error(f"Product {pid} not found")
                    continue

            if items_processed > 0:
                order.total_amount = total_calculated
                order.save(update_fields=['total_amount'])

        # Shared-cart gift: the recipient owns the order, while the payer remains
        # recorded separately. Notify the recipient and each affected seller,
        # explicitly naming the recipient (sender) in the seller message.
        if isinstance(shared_purchase, dict) and shared_purchase.get('action') == 'gift' and gift_recipient:
            UserNotification.objects.create(
                user=gift_recipient,
                title='🎁 Shared-cart payment received',
                message=f'{req.user.username} has made payment for an item from your shared cart. Order #{order.id} is now in your orders.',
                link=reverse('store:order_receipt', args=[order.id]),
            )
            seller_ids = set()
            for oi in order.items.select_related('product__seller').all():
                seller = getattr(oi.product, 'seller', None)
                if seller and getattr(seller, 'user_id', None):
                    seller_ids.add(seller.user_id)
            for seller_user_id in seller_ids:
                UserNotification.objects.create(
                    user_id=seller_user_id,
                    title='💳 Payment received for shared-cart order',
                    message=f'{req.user.username} made payment for {gift_recipient.username} (the shared-cart sender). Please process Order #{order.id}.',
                    link=reverse('store:order_receipt', args=[order.id]),
                )

        # Clear cart session
        req.session['cart'] = {}
        req.session.pop('shared_purchase', None)
        req.session.pop('paystack_ref', None)
        req.session.pop('paystack_amount', None)
        req.session.modified = True

        return JsonResponse({'success': True, 'order_id': order.id, 'message': 'Payment successful'})

    except requests.exceptions.Timeout:
        logger.error(f"Verification timeout: {reference}")
        return JsonResponse({'success': False, 'error': 'Payment verification timeout'}, status=503)
    except Exception as e:
        logger.exception(f"Callback error: {e}")
        return JsonResponse({'success': False, 'error': str(e)}, status=500)


@guest_or_login_required
def verify_paystack_payment(req):
    """Verify Paystack transaction after customer completes payment"""
    reference = req.GET.get('reference') or req.session.get('paystack_ref')

    if not reference:
        logger.warning("Payment verification attempted without reference")
        messages.error(req, "❌ No payment reference found. Please contact support.")
        return redirect("store:cart") if req.user.is_authenticated else redirect("store:home")

    if not reference.startswith("SV-"):
        logger.warning(f"Invalid reference format: {reference}")
        messages.error(req, "❌ Invalid payment reference.")
        return redirect("store:cart") if req.user.is_authenticated else redirect("store:home")

    # 1️⃣ Check if order was already created (e.g., by callback/webhook or page refresh)
    existing_order = Order.objects.filter(reference=reference).first()
    if existing_order:
        req.session['cart'] = {}
        req.session.pop('paystack_ref', None)
        req.session.pop('paystack_amount', None)
        req.session.pop('shared_purchase', None)
        req.session.modified = True
        messages.success(req, f"✅ Payment successful! Order #{existing_order.id} confirmed.")
        if req.user.is_authenticated and (existing_order.user_id == req.user.id or existing_order.paid_by_id == req.user.id):
            return redirect("store:order_success", order_id=existing_order.id)
        return redirect('store:home')

    try:
        verify_url = f"https://api.paystack.co/transaction/verify/{reference}"
        headers = {
            "Authorization": f"Bearer {settings.PAYSTACK_SECRET_KEY}",
            "Content-Type": "application/json",
        }

        response = requests.get(verify_url, headers=headers, timeout=30)

        if response.status_code in [400, 404]:
            messages.error(req, "❌ Invalid payment reference or transaction not found.")
            return redirect("store:checkout")

        response.raise_for_status()
        data = response.json()

        if not (data.get('status') and data.get('data', {}).get('status') == 'success'):
            status = data.get('data', {}).get('status', 'unknown')
            messages.error(req, f"❌ Payment status: {status}. Please contact support.")
            return redirect("store:checkout")

        paystack_data = data['data']
        paid_amount_ghs = Decimal(paystack_data.get('amount', 0)) / Decimal('100')
        fallback_email = req.user.email if req.user.is_authenticated else ''
        customer_email = paystack_data.get('customer', {}).get('email') or fallback_email

        # Validate amount
        expected_amount_str = req.session.get('paystack_amount')
        if expected_amount_str:
            expected_amount = Decimal(expected_amount_str)
            if abs(paid_amount_ghs - expected_amount) > Decimal('0.01'):
                logger.error(f"Amount mismatch: paid={paid_amount_ghs}, expected={expected_amount}")
                messages.error(req, "❌ Payment amount mismatch. Order not processed.")
                return redirect("store:checkout")

        cart_data = req.session.get('cart', {})
        if not isinstance(cart_data, dict) or not cart_data:
            messages.error(req, "❌ Cart data not found. Please contact support.")
            return redirect("store:home")

        shared_purchase = req.session.get('shared_purchase')
        gift_recipient = None
        if isinstance(shared_purchase, dict) and shared_purchase.get('action') == 'gift':
            gift_recipient = User.objects.filter(id=shared_purchase.get('owner_id')).first()
            if not gift_recipient:
                messages.error(req, 'The shared-cart recipient could not be found.')
                return redirect('store:cart') if req.user.is_authenticated else redirect('store:home')

        if not req.user.is_authenticated and not gift_recipient:
            # Guests are only ever allowed through for a shared-cart gift
            # (enforced by guest_or_login_required); if that session detail
            # is missing here, there is no account to attach the order to.
            messages.error(req, "❌ Your checkout session has expired. Please open the shared cart link again.")
            return redirect('store:home')

        # 2️⃣ Atomic transaction wrapper
        with transaction.atomic():
            order = Order.objects.create(
                user=gift_recipient or req.user,
                paid_by=req.user if req.user.is_authenticated else None,
                reference=reference,
                total_amount=paid_amount_ghs,
                payment_status='paid',
                payment_method='paystack',
                paystack_response=paystack_data,
                guest_email=(customer_email or '') if not req.user.is_authenticated else None,
            )

            # Burn the Community Highlights voucher, if one was applied.
            _consume_applied_voucher(req, order)

            total_calculated = Decimal('0')
            items_processed = 0

            # An invoice purchase uses the agreed price and delivery fee, so
            # it skips the cart pricing loop entirely.
            paid_invoice = _active_invoice(req)
            if paid_invoice:
                _record_invoice_order(req, order, paid_invoice, paid_amount_ghs)

            for pid, item in ({} if paid_invoice else cart_data).items():
                try:
                    if isinstance(item, dict):
                        qty = item.get('quantity', 1)
                        color = item.get('color', '')
                        size = item.get('size', '')
                        while isinstance(qty, dict):
                            qty = qty.get('quantity', 1)
                        qty = max(1, int(float(qty)))
                    else:
                        qty = max(1, int(float(item)))
                        color = ''
                        size = ''

                    # select_for_update() MUST be inside transaction.atomic()
                    product = Product.objects.select_for_update().get(id=int(_parse_cart_key(pid)[0]), is_active=True)

                    if product.stock < qty:
                        messages.warning(req, f"⚠️ {product.name} has limited stock. Quantity adjusted.")
                        qty = max(0, product.stock)

                    if qty > 0:
                        line_total = product.price * Decimal(qty)
                        OrderItem.objects.create(
                            order=order,
                            product=product,
                            quantity=qty,
                            price=product.price,
                            subtotal=line_total,
                            color=color,
                            size=size,
                        )
                        product.stock -= qty
                        product.save(update_fields=['stock'])

                        total_calculated += line_total
                        items_processed += 1

                except Product.DoesNotExist:
                    logger.error(f"Product {pid} not found during processing")
                    continue

            if items_processed > 0 and not paid_invoice:
                order.total_amount = total_calculated
                order.save(update_fields=['total_amount'])

        req.session.pop('invoice_checkout', None)

        for pid in cart_data.keys():
            try:
                product = Product.objects.get(id=int(_parse_cart_key(pid)[0]))
                _drop_from_shared_carts(product)
            except Exception:
                pass

        payer_label = req.user.username if req.user.is_authenticated else f'A guest ({customer_email})' if customer_email else 'A guest'

        if isinstance(shared_purchase, dict) and shared_purchase.get('action') == 'gift' and gift_recipient:
            UserNotification.objects.create(
                user=gift_recipient,
                title='🎁 Shared-cart payment received',
                message=f'{payer_label} has made payment for your shared-cart item. Order #{order.id} is now in your orders.',
                link=reverse('store:order_receipt', args=[order.id]),
            )
            seller_ids = set()
            for oi in order.items.select_related('product__seller').all():
                seller = getattr(oi.product, 'seller', None)
                if seller and getattr(seller, 'user_id', None):
                    seller_ids.add(seller.user_id)
            for seller_user_id in seller_ids:
                UserNotification.objects.create(
                    user_id=seller_user_id,
                    title='💳 Payment received for shared-cart order',
                    message=f'{payer_label} made payment for {gift_recipient.username} (the shared-cart sender). Please process Order #{order.id}.',
                    link=reverse('store:order_receipt', args=[order.id]),
                )

        req.session['cart'] = {}
        req.session.pop('paystack_ref', None)
        req.session.pop('paystack_amount', None)
        req.session.pop('shared_purchase', None)
        req.session.modified = True

        messages.success(req, f"✅ Payment successful! Order #{order.id} confirmed.")
        if req.user.is_authenticated and (order.user_id == req.user.id or order.paid_by_id == req.user.id):
            return redirect("store:order_success", order_id=order.id)
        return redirect('store:home')

    except IntegrityError:
        # Catch duplicate creation attempts gracefully
        order = Order.objects.get(reference=reference)
        if req.user.is_authenticated and (order.user_id == req.user.id or order.paid_by_id == req.user.id):
            return redirect("store:order_success", order_id=order.id)
        return redirect('store:home')

    except requests.exceptions.Timeout:
        messages.error(req, "⏳ Payment verification timed out. Please check your orders.")
        return redirect("store:user_orders") if req.user.is_authenticated else redirect("store:home")

    except Exception as e:
        logger.exception(f"Unexpected error verifying payment {reference}: {e}")
        messages.error(req, "❌ An unexpected error occurred. Please contact support.")
        return redirect("store:checkout")

@login_required
def order_success(req, order_id):
    """Order success page"""
    try:
        order = Order.objects.get(id=order_id)
        if order.user_id != req.user.id and order.paid_by_id != req.user.id:
            return redirect('store:home')
        return render(req, "store/order_success.html", {"order": order})
    except Order.DoesNotExist:
        return redirect("store:home")

@login_required
def order_receipt(req, order_id):
    """Display order receipt/invoice"""
    order = get_object_or_404(Order, id=order_id)
    
    # Security: Only allow user or staff to view receipt
    if order.user != req.user and not req.user.is_staff:
        # Sellers can view receipts for their orders
        if hasattr(req.user, 'seller_profile'):
            if not OrderItem.objects.filter(order=order, product__seller=req.user.seller_profile).exists():
                return redirect('store:home')
        else:
            return redirect('store:home')
    
    return render(req, "store/order_receipt.html", {"order": order})

# ==================== USER PROFILE ====================
# store/views.py

@login_required
def profile(req):
    profile = req.user.user_profile
    seller = getattr(req.user, "seller_profile", None)
    
    if req.method == "POST":
        avatar_file = req.FILES.get("avatar")
        if avatar_file:
            supa_url = upload_avatar_to_supabase(req.user.id, avatar_file)
            if supa_url:
                profile.avatar = supa_url  
                profile.save(update_fields=["avatar"])
                messages.success(req, "✅ Avatar updated!")
            else:
                messages.error(req, "❌ Avatar upload failed. Try again.")
        
        # Handle other fields...
        whatsapp = req.POST.get("whatsapp_number", "").strip()
        bio = req.POST.get("bio", "").strip()
        if whatsapp: profile.whatsapp_number = whatsapp
        if bio: profile.bio = bio
        country = req.POST.get("country", "").strip()
        if country: profile.country = country
        profile.save(update_fields=["whatsapp_number", "bio", "country", "avatar"])
        
        # ✅ Always redirect to force fresh context load
        return redirect("store:profile")
    
    return render(req, "store/profile.html", {
        "profile": profile,
        "seller": seller,
        "avatar_url": profile.get_avatar_url()  # ✅ Passes correct URL
    })
        

# ==================== SELLER PORTAL ====================
# In seller_signup view:
# store/views.py

from django.shortcuts import render, redirect
from django.contrib import messages
from django.contrib.auth import login
from .forms import SellerSignupForm

@login_required  # ✅ User must be logged in to become a seller
def seller_signup(req):
    # If user already has a seller profile, redirect appropriately
    if hasattr(req.user, 'seller_profile'):
        status = req.user.seller_profile.status
        if status == 'approved':
            messages.info(req, "✅ You already have an approved seller account.")
            return redirect('store:seller_dashboard')
        elif status == 'pending':
            messages.warning(req, "⏳ Your application is pending admin review.")
            return redirect('store:profile')
        # If rejected, allow them to reapply below

    if req.method == 'POST':
        form = SellerSignupForm(req.POST, user=req.user) 
        if form.is_valid():
            try:
                with transaction.atomic():
                    # Update existing user (don't create new one)
                    user = req.user
                    user.email = form.cleaned_data['email']
                    if form.cleaned_data['password']:  # Only update if new password provided
                        user.set_password(form.cleaned_data['password'])
                    user.save()
                    
                    # Create SellerProfile linked to existing user
                    seller_profile = SellerProfile.objects.create(
                        user=user,
                        store_name=form.cleaned_data['store_name'],
                        phone=form.cleaned_data['phone'],
                        address=form.cleaned_data['address'],
                        payment_number=form.cleaned_data.get('payment_number', ''),
                        status='pending',
                        is_verified=False
                    )
                    
                    messages.success(req, f"✅ Application submitted! '{seller_profile.store_name}' pending review.")
                    return redirect('store:home')
                    
            except Exception as e:
                import logging
                logging.error(f"Seller signup failed: {e}")
                messages.error(req, "Registration failed. Please try again.")
        else:
            # Console debug output
            print("\n" + "🔴" * 40)
            print(" 🛑 SELLER SIGNUP VALIDATION FAILED ")
            print("🔴" * 40)
            print(f"📥 SUBMITTED DATA: {dict(req.POST)}")
            print("\n❌ VALIDATION ERRORS:")
            for field, errors in form.errors.items():
                print(f"   🔸 {field.upper()}: {', '.join(errors)}")
            print("🔴" * 40 + "\n")
            messages.error(req, "Please correct the errors below.")
    else:
        # ✅ PRE-FILL FORM WITH EXISTING USER DATA
        initial_data = {
            'username': req.user.username,
            'email': req.user.email,
            # Password fields left empty for security
        }
        form = SellerSignupForm(initial=initial_data, user=req.user)

    return render(req, 'store/seller_signup.html', {'form': form})

@login_required
@seller_required
def seller_dashboard(req):
    s = req.user.seller_profile
    prods = Product.objects.filter(seller=s)
    orders = Order.objects.filter(items__product__seller=s).distinct()
    stats = {
        "sales": orders.aggregate(t=Sum("total_amount"))["t"] or 0,
        "units": OrderItem.objects.filter(product__seller=s).aggregate(c=Count("id"))["c"] or 0,
        "count": orders.count()
    }
    

    statuses = ["Pending", "Processing", "Shipped", "In Transit", "Out for Delivery", "Delivered", "Cancelled"]

    # Community Highlights: the seller's engagement goal + how it's performing.
    from .models import SellerHighlightGoal, CommunityHighlight, DiscountVoucher
    highlight_goal = SellerHighlightGoal.for_seller(s)
    seller_highlights = CommunityHighlight.objects.filter(seller=s)
    highlight_stats = {
        "posts": seller_highlights.count(),
        "points": seller_highlights.aggregate(t=Sum("total_points"))["t"] or 0,
        "vouchers": DiscountVoucher.objects.filter(seller=s).count(),
    }

    return render(req, "store/seller_dashboard.html", {
        "profile": s,
        "products": prods,
        "orders": orders,
        "stats": stats,
        "statuses": statuses,
        "highlight_goal": highlight_goal,
        "highlight_stats": highlight_stats,
    })

# store/views.py


@login_required
def seller_analytics(req):
    """Seller analytics dashboard with revenue charts"""
    seller = get_object_or_404(SellerProfile, user=req.user)
    
    # Get seller's paid orders only
    orders = Order.objects.filter(
        items__product__seller=seller,
        payment_status='paid'
    ).distinct()
    
    # ✅ Total revenue - use total_amount (NOT total or total_)
    total_revenue = orders.aggregate(r=Sum("total_amount"))["r"] or 0
    
    # ✅ Order count
    order_count = orders.count()
    
    # ✅ Monthly revenue for Chart.js
    monthly = orders.annotate(
        mo=TruncMonth("created_at")
    ).values("mo").annotate(
        revenue=Sum("total_amount")  # ✅ FIXED: total_amount, not total_
    ).order_by("mo")
    
    # Format for frontend
    chart_labels = [item["mo"].strftime("%b %Y") for item in monthly]
    chart_data = [float(item["revenue"] or 0) for item in monthly]
    
    # ✅ Top selling products
    top_products = OrderItem.objects.filter(
        order__in=orders,
        product__seller=seller
    ).values(
        "product__name", "product__id"
    ).annotate(
        sold=Sum("quantity"),
        revenue=Sum("subtotal")
    ).order_by("-sold")[:5]
    
    context = {
        "seller": seller,
        "revenue": float(total_revenue),
        "order_count": order_count,
        "chart_labels": chart_labels,
        "chart_data": chart_data,
        "top_products": list(top_products),
        "statuses": ["pending", "processing", "shipped", "delivered", "cancelled"],
    }
    
    return render(req, "store/seller_analytics.html", context)
# store/views.py


@login_required
@seller_required
def fix_glb_diffuse_factors(glb_bytes):
    """
    Fix GLB files where diffuseFactor is white [1,1,1,1], washing out texture colours.
    Samples real pixel colour from each material texture and writes it back.
    Always returns valid bytes — original if anything fails.
    """
    import struct, json, io
    try:
        from PIL import Image
    except ImportError:
        return glb_bytes

    try:
        data = bytearray(glb_bytes)

        if data[:4] != b"glTF":
            return glb_bytes  # not a GLB file

        # ── Parse JSON chunk ──────────────────────────────────
        chunk0_len = struct.unpack_from("<I", data, 12)[0]
        gltf       = json.loads(data[20:20 + chunk0_len])

        # ── Parse binary chunk ────────────────────────────────
        bin_start  = 20 + chunk0_len
        chunk1_len = struct.unpack_from("<I", data, bin_start)[0]
        bin_data   = bytes(data[bin_start + 8 : bin_start + 8 + chunk1_len])

        bv_list  = gltf.get("bufferViews", [])
        img_list = gltf.get("images", [])
        tex_list = gltf.get("textures", [])

        def sample_color(tex_idx):
            src   = tex_list[tex_idx]["source"]
            bv    = bv_list[img_list[src]["bufferView"]]
            chunk = bin_data[bv["byteOffset"]: bv["byteOffset"] + bv["byteLength"]]
            img   = Image.open(io.BytesIO(chunk)).convert("RGB")
            w, h  = img.size
            pts   = [(int(fx*w), int(fy*h)) for fx in (.2,.4,.5,.6,.8) for fy in (.2,.4,.5,.6,.8)]
            avg   = tuple(sum(img.getpixel(p)[i] for p in pts)//len(pts) for i in range(3))
            return [round(c/255, 4) for c in avg] + [1.0]

        changed = False

        # Fix KHR_materials_pbrSpecularGlossiness (older PBR format — most white-wash cases)
        for mat in gltf.get("materials", []):
            ext = mat.get("extensions", {}).get("KHR_materials_pbrSpecularGlossiness", {})
            df  = ext.get("diffuseFactor", [0,0,0,1])
            if df[0] > 0.95 and df[1] > 0.95 and df[2] > 0.95:
                dt = ext.get("diffuseTexture")
                if dt:
                    try:
                        ext["diffuseFactor"] = sample_color(dt["index"])
                        changed = True
                    except Exception:
                        pass  # skip this material, leave as-is

        # Also fix standard PBR baseColorFactor if it is white and has a texture
        for mat in gltf.get("materials", []):
            pbr = mat.get("pbrMetallicRoughness", {})
            bf  = pbr.get("baseColorFactor", [0,0,0,1])
            if bf[0] > 0.95 and bf[1] > 0.95 and bf[2] > 0.95:
                bt = pbr.get("baseColorTexture")
                if bt:
                    try:
                        pbr["baseColorFactor"] = sample_color(bt["index"])
                        changed = True
                    except Exception:
                        pass

        if not changed:
            return glb_bytes  # nothing needed fixing

        # ── Rebuild GLB with updated JSON ─────────────────────
        new_json = json.dumps(gltf, separators=(",",":")).encode("utf-8")
        # Pad to 4-byte boundary with spaces (GLB spec)
        while len(new_json) % 4:
            new_json += b" "

        # Update chunk0 length and total file length in header
        size_diff = len(new_json) - chunk0_len
        new_total = struct.unpack_from("<I", data, 8)[0] + size_diff
        struct.pack_into("<I", data, 8,  new_total)
        struct.pack_into("<I", data, 12, len(new_json))

        # Splice new JSON into the buffer
        fixed = bytes(data[:20]) + new_json + bytes(data[20 + chunk0_len:])
        return fixed

    except Exception:
        return glb_bytes  # always safe


def upload_product(req):
    """Handle product upload with single category selection"""
    if req.method == "POST":
        form = ProductUploadForm(req.POST, req.FILES)
        if form.is_valid():
            product = form.save(commit=False)
            product.seller = req.user.seller_profile
            
            # Handle image upload to Supabase Storage
            uploaded_file = req.FILES.get("image")
            if uploaded_file:
                ext = uploaded_file.name.split(".")[-1].lower()
                filename = f"products/{uuid.uuid4()}.{ext}"
                try:
                    supabase = get_supabase_client()
                    supabase.storage.from_("product-uploads").upload(
                        filename, 
                        uploaded_file.read(), 
                        {"content-type": uploaded_file.content_type}
                    )
                    product.supabase_image_path = filename
                except Exception as e:
                    messages.error(req, f"❌ Image upload failed: {str(e)}")
                    return render(req, "store/upload_product.html", {"form": form})

            # ── Handle VR / 3D file upload to Supabase ──
            vr_enabled = req.POST.get("vr_enabled")
            vr_file = req.FILES.get("vr_model") or req.FILES.get("vr_image")
            if vr_enabled and vr_file:
                vr_type = req.POST.get("vr_type", "3d_model")
                ext = vr_file.name.split(".")[-1].lower()
                vr_filename = f"products/vr/{uuid.uuid4()}.{ext}"

                # Set correct content-type per file type
                content_type_map = {
                    "glb":  "model/gltf-binary",
                    "gltf": "model/gltf+json",
                    "jpg":  "image/jpeg",
                    "jpeg": "image/jpeg",
                    "jfif": "image/jpeg",
                    "png":  "image/png",
                    "webp": "image/webp",
                }
                vr_content_type = content_type_map.get(ext, vr_file.content_type)

                try:
                    vr_bytes = vr_file.read()

                    # Auto-fix colour washing on GLB files
                    if ext == "glb":
                        try:
                            vr_bytes = fix_glb_diffuse_factors(vr_bytes)
                        except Exception:
                            pass  # skip fix silently, upload original

                    supabase = get_supabase_client()
                    supabase.storage.from_("product-uploads").upload(
                        vr_filename,
                        vr_bytes,
                        {"content-type": vr_content_type, "upsert": "true"}
                    )
                    product.vr_supabase_path = vr_filename
                    product.vr_type = vr_type
                except Exception as e:
                    messages.warning(req, f"⚠️ VR upload failed: {str(e)}")
            else:
                product.vr_supabase_path = None
                product.vr_type = None
            
            # ✅ Category is already handled by the form's ModelChoiceField
            # No need for custom_category logic anymore
            product.save()
            
            messages.success(req, f'✅ "{product.name}" uploaded successfully!')
            return redirect("store:upload_product")
    else:
        form = ProductUploadForm()
    
    return render(req, "store/upload_product.html", {"form": form})

@login_required
@seller_required
def delete_product(req, product_id):
    if req.method != 'POST': return redirect("store:seller_dashboard")
    product = get_object_or_404(Product, id=product_id)
    if product.seller != req.user.seller_profile and not req.user.is_superuser: messages.error(req, "🚫 You can only delete your own products."); return redirect("store:seller_dashboard")
    product_name = product.name
    if product.supabase_image_path:
        try: supabase = get_supabase_client(); supabase.storage.from_("product-uploads").remove([product.supabase_image_path])
        except Exception: pass
    product.delete()
    messages.success(req, f"🗑️ '{product_name}' deleted."); return redirect("store:admin_dashboard" if req.user.is_superuser else "store:seller_dashboard")

# ==================== USER ORDERS ====================
@login_required
def order_history(req):
    orders = Order.objects.filter(user=req.user).order_by("-created_at")
    orders_with_details = []
    for order in orders:
        items = order.items.select_related("product").all()
        orders_with_details.append({"order": order, "item_count": items.count(), "items": items[:3]})
    return render(req, "store/order_history.html", {"orders": orders_with_details, "total_orders": len(orders)})


# ==================== ADMIN DASHBOARD ====================

from django.contrib.auth.decorators import login_required, user_passes_test
from django.db.models import Sum
from .models import User, Product, Order, SellerProfile  # ✅ Ensure SellerProfile is imported

# Note: @superuser_required isn't built into Django. Using standard check below:
@login_required
@user_passes_test(lambda u: u.is_superuser)
def admin_dashboard(req):
    users = User.objects.all().order_by("-date_joined")
    products = Product.objects.select_related("category", "seller").order_by("-created_at")
    stats = {
        "users": users.count(), 
        "sellers": users.filter(seller_profile__isnull=False).count(), 
        "products": products.count(), 
        "orders": Order.objects.count(), 
        "revenue": Order.objects.aggregate(total=Sum("total_amount"))["total"] or 0
    }
    
    pending_sellers = SellerProfile.objects.filter(status='pending').select_related('user').order_by('-created_at')

    return render(req, "store/admin_dashboard.html", {
        "users": users,
        "products": products,
        "stats": stats,
        "recent_orders": Order.objects.select_related("user").order_by("-created_at")[:5],
        "statuses": ["Pending", "Processing", "Shipped", "Delivered", "Cancelled"],
        "pending_sellers": pending_sellers  # ✅ Passed to template for the approval table
    })

@login_required
@superuser_required
def admin_add_user(req):
    if req.method == "POST":
        email, username, password, role = req.POST.get("email"), req.POST.get("username"), req.POST.get("password"), req.POST.get("role", "buyer")
        if not all([email, username, password]): messages.error(req, "❌ All fields required."); return redirect("store:admin_dashboard")
        supabase = get_supabase_client()
        try:
            supabase.auth.admin.create_user({"email": email, "password": password, "email_confirm": True, "user_metadata": {"username": username, "role": role}})
            User.objects.get_or_create(username=username, defaults={"email": email, "is_superuser": role == "admin"})
            messages.success(req, f"✅ User '{username}' created.")
        except Exception as e: messages.error(req, f"❌ Failed: {str(e)}")
    return redirect("store:admin_dashboard")

@login_required
@superuser_required
def admin_remove_user(req, user_id):
    if req.method != "POST": return redirect("store:admin_dashboard")
    user = get_object_or_404(User, id=user_id)
    if user.is_superuser: messages.error(req, "❌ Cannot delete superadmin."); return redirect("store:admin_dashboard")
    supabase = get_supabase_client()
    try:
        for u in supabase.auth.admin.list_users().users:
            if getattr(u, "email", "") == user.email: supabase.auth.admin.delete_user(u.id); break
    except Exception: pass
    user.delete(); messages.success(req, f"✅ User '{user.username}' removed."); return redirect("store:admin_dashboard")

@login_required
@superuser_required
def admin_update_price(req, product_id):
    if req.method == "POST":
        product = get_object_or_404(Product, id=product_id)
        try: product.price = float(req.POST.get("price")); product.save(); messages.success(req, f"✅ Price updated.")
        except ValueError: messages.error(req, "❌ Invalid price format.")
    return redirect("store:admin_dashboard")

@login_required
@superuser_required
def admin_analytics(req):
    """Admin analytics dashboard with charts and stats"""
    from django.db.models import Sum, Count, Avg
    from django.db.models.functions import TruncMonth
    import json
    
    # 🔹 Overall Stats
    total_users = User.objects.count()
    total_sellers = User.objects.filter(seller_profile__isnull=False).count()
    total_products = Product.objects.count()
    total_orders = Order.objects.count()
    total_revenue = Order.objects.aggregate(total=Sum("total"))["total"] or 0
    
    # 🔹 Monthly Revenue Chart Data
    monthly_revenue = Order.objects.annotate(
        month=TruncMonth("created_at")
    ).values("month").annotate(
        revenue=Sum("total"),
        order_count=Count("id")
    ).order_by("month")
    
    months = [item["month"].strftime("%b %Y") for item in monthly_revenue]
    revenues = [float(item["revenue"] or 0) for item in monthly_revenue]
    order_counts = [item["order_count"] for item in monthly_revenue]
    
    # 🔹 Top Selling Products
    top_products = OrderItem.objects.values(
        "product__name", "product__id"
    ).annotate(
        total_sold=Sum("quantity"),
        revenue=Sum("price")
    ).order_by("-total_sold")[:10]
    
    # 🔹 Recent Orders
    recent_orders = Order.objects.select_related("user").order_by("-created_at")[:10]
    
    # 🔹 Seller Performance
    seller_stats = SellerProfile.objects.annotate(
        product_count=Count("products", distinct=True),
        order_count=Count("products__order_items__order", distinct=True),  
        total_sales=Sum("products__order_items__price")
    ).order_by("-total_sales")[:10]
    
    # ✅ ADD THIS LINE: Fetch pending sellers for approval workflow
    pending_sellers = SellerProfile.objects.filter(status='pending').select_related('user').order_by('-created_at')[:10]
    
    return render(req, "store/admin_analytics.html", {
        "stats": {
            "users": total_users, "sellers": total_sellers, "products": total_products,
            "orders": total_orders, "revenue": total_revenue
        },
        "chart_data": {
            "months": json.dumps(months),
            "revenues": json.dumps(revenues),
            "order_counts": json.dumps(order_counts)
        },
        "top_products": top_products,
        "recent_orders": recent_orders,
        "seller_stats": seller_stats,
        # ✅ ADD THIS: Pass pending sellers to template
        "pending_sellers": pending_sellers,
    })

@login_required
@superuser_required
def admin_orders(req):
    """Admin order management page"""
    # Filtering
    status_filter = req.GET.get("status", "")
    search_query = req.GET.get("q", "")
    
    orders = Order.objects.select_related("user").prefetch_related("items__product").order_by("-created_at")
    
    if status_filter:
        orders = orders.filter(status=status_filter)
    if search_query:
        orders = orders.filter(
            Q(id__icontains=search_query) |
            Q(user__username__icontains=search_query) |
            Q(user__email__icontains=search_query) |
            Q(items__product__name__icontains=search_query)
        ).distinct()
    
    # Pagination (optional)
    from django.core.paginator import Paginator
    paginator = Paginator(orders, 20)  # 20 orders per page
    page_number = req.GET.get("page")
    page_obj = paginator.get_page(page_number)
    
    return render(req, "store/admin_orders.html", {
        "orders": page_obj,
        "status_filter": status_filter,
        "search_query": search_query,
        "statuses": ["Pending", "Processing", "Shipped", "Delivered", "Cancelled"]
    })

@login_required
@superuser_required
def admin_update_order_status(req, order_id):
    """Update order status (AJAX endpoint)"""
    if req.method != "POST":
        return redirect("store:admin_orders")
    
    order = get_object_or_404(Order, id=order_id)
    new_status = req.POST.get("status")
    
    if new_status in ["Pending", "Processing", "Shipped", "Delivered", "Cancelled"]:
        order.status = new_status
        order.save()
        messages.success(req, f"✅ Order #{order.id} status updated to {new_status}.")
    else:
        messages.error(req, "❌ Invalid status.")
    
    return redirect("store:admin_orders")

@login_required
def user_orders(req):
    """Display user's order & transaction history"""
    orders = Order.objects.filter(user=req.user).select_related('user').prefetch_related('items__product').order_by('-created_at')
    
    # Pagination
    paginator = Paginator(orders, 8)
    page_number = req.GET.get('page')
    page_obj = paginator.get_page(page_number)
    
    return render(req, 'store/user_orders.html', {
        'page_obj': page_obj,
        'orders': page_obj.object_list
    })

@login_required
def track_order(req, order_id):
    """Buyer-facing order tracking page with location timeline"""
    order = get_object_or_404(Order, id=order_id, user=req.user)
    
    # ✅ Map any DB variation to clean display names
    status_map = {
        'pending': 'Pending', 'processing': 'Processing', 'shipped': 'Shipped',
        'in_transit': 'In Transit', 'in transit': 'In Transit',
        'out_for_delivery': 'Out for Delivery', 'out for delivery': 'Out for Delivery',
        'delivered': 'Delivered', 'cancelled': 'Cancelled'
    }
    
    raw = (order.status or 'pending').lower()
    current_status = status_map.get(raw, 'Pending')
    
    status_order = ["Pending", "Processing", "Shipped", "In Transit", "Out for Delivery", "Delivered"]
    
    # ✅ Safely get location (replaces order.delivery_location)
    location = getattr(order, 'shipping_address', getattr(order, 'delivery_address', None))
    # Fallback to city if address fields don't exist
    if not location:
        location = getattr(order, 'shipping_city', getattr(order, 'city', None))
    
    timeline = []
    try:
        current_index = status_order.index(current_status)
    except ValueError:
        current_index = 0
    
    for i, status in enumerate(status_order):
        if i == current_index:
            timeline.append({
                "status": status,
                "active": True,
                "date": order.delivered_at if status == "Delivered" else order.created_at,
                "location": location if status in ["In Transit", "Out for Delivery", "Delivered"] else None
            })
        elif i < current_index:
            timeline.append({
                "status": status,
                "active": False,
                "date": order.created_at,
                "location": None
            })
        else:
            break
            
    return render(req, "store/track_order.html", {
        "order": order,
        "timeline": timeline,
        "can_cancel": current_status in ["Pending", "Processing"]
    })

@login_required
def cancel_order(req, order_id):
    """Handle order cancellation"""
    order = get_object_or_404(Order, id=order_id, user=req.user)
    
    # Allow cancellation only if Pending or Processing (handle both casings)
    if order.status in ['Pending', 'Processing', 'pending', 'processing']:
        order.status = 'Cancelled'
        order.save()
        messages.success(req, "Order cancelled successfully.")
    else:
        messages.error(req, "This order cannot be cancelled at this stage.")
        
    return redirect('store:track_order', order_id=order_id)

@login_required
def update_order_status(req, order_id):
    """Allow sellers/admin to update order status"""
    if req.method != "POST":
        return redirect("store:order_history")
    
    order = get_object_or_404(Order, id=order_id)
    new_status = req.POST.get("status", "").strip()
    
    # Permission check
    if not req.user.is_superuser:
        seller = getattr(req.user, 'seller_profile', None)
        if not seller or not order.items.filter(product__seller=seller).exists():
            messages.error(req, "🚫 You can only manage your own orders.")
            return redirect("store:order_history")
    
    # ✅ Get valid statuses directly from model
    status_field = Order._meta.get_field('status')
    valid_statuses = [choice[0] for choice in status_field.choices]
    
    #  DEBUG: See exactly what's being submitted vs expected
    print(f"📥 Submitted: '{new_status}'")
    print(f"✅ Valid: {valid_statuses}")
    
    # Normalize input to lowercase for safe comparison
    normalized = new_status.lower()
    valid_lower = [s.lower() for s in valid_statuses]
    
    if normalized in valid_lower:
        # Find the exact model key that matches
        order.status = next(s for s in valid_statuses if s.lower() == normalized)
        order.save()
        messages.success(req, f"✅ Order #{order.id} updated to {order.status.title()}")
    else:
        messages.error(req, f"❌ Invalid status. Choose from: {', '.join(valid_statuses)}")
    
    # Redirect based on role
    if req.user.is_superuser:
        return redirect("store:admin_orders")
    return redirect("store:seller_dashboard")
@login_required
def complete_profile(req):
    """Handle profile completion for new users"""
    profile, _ = UserProfile.objects.get_or_create(user=req.user)

    if req.method == "POST":
        # ✅ Handle text-based country field
        country = req.POST.get("country", "").strip()
        whatsapp = req.POST.get("whatsapp_number", "").strip()

        if country:
            profile.country = country
        if whatsapp:
            profile.whatsapp_number = whatsapp

        profile.save(update_fields=["country", "whatsapp_number"])

        # Sync to Supabase if needed
        try:
            update_supabase_prof(req.user.id, {
                "country": country,
                "whatsapp_number": whatsapp
            })
        except Exception:
            # Don't block profile completion on a Supabase sync hiccup
            pass

        messages.success(req, "✅ Profile completed!")

        # Redirect to intended page or home
        next_url = req.POST.get("next") or req.GET.get("next") or "store:home"
        return redirect(next_url)

    return render(req, "store/complete_profile.html", {
        "profile": profile,
        "next": req.GET.get("next", "store:home")
    })


def contact_support(req):
    """Simple support-contact page. Linked from profile.html for sellers
    whose application was rejected, and available to anyone else."""
    support_email = getattr(settings, "ADMIN_EMAIL", None) or getattr(settings, "DEFAULT_FROM_EMAIL", None)
    return render(req, "store/contact_support.html", {
        "support_email": support_email,
    })


def get_regions_by_country(req):
    """API endpoint to fetch regions for a selected country"""
    country_id = req.GET.get('country_id')
    if country_id:
        regions = Region.objects.filter(country_id=country_id, is_active=True).values('id', 'name', 'code')
        return JsonResponse({'regions': list(regions)})
    return JsonResponse({'regions': []})


@require_POST
def save_delivery_info(req):
    """Stores the buyer's delivery region/city in their session. Shown once
    via a modal before the first item is added to the cart, so we know
    where to deliver without forcing it into every product's variant form."""
    region = (req.POST.get('region') or '').strip()
    city = (req.POST.get('city') or '').strip()
    if not region or not city:
        return JsonResponse({'success': False, 'error': 'Please select a region and enter a city.'}, status=400)
    req.session['delivery_region'] = region
    req.session['delivery_city'] = city
    req.session.modified = True
    return JsonResponse({'success': True, 'region': region, 'city': city})


@login_required
def product_detail(req, slug):
    product = get_object_or_404(Product, slug=slug, is_active=True)
    seller_prof = get_supabase_prof(product.seller.user_id) if product.seller else None
    # Buyers now talk to sellers in-site rather than being handed off to
    # WhatsApp, so no phone number is exposed on this page.
    conversation = None
    if req.user.is_authenticated and product.seller:
        conversation = Conversation.objects.filter(product=product, buyer=req.user).first()
    related_products = Product.objects.filter(category=product.category, is_active=True, stock__gt=0).exclude(id=product.id).order_by('-created_at')[:4]
    reviews = Review.objects.filter(product=product).filter(Q(is_approved=True) | Q(user=req.user)).select_related('user').order_by('-created_at')

    if req.method == 'POST':
        rating = req.POST.get('rating'); comment = req.POST.get('comment', '').strip(); image = req.FILES.get('image')
        try: rating_value = int(rating)
        except (TypeError, ValueError): rating_value = 0
        if not 1 <= rating_value <= 5:
            messages.error(req, 'Please select a rating from 1 to 5 stars.'); return redirect('store:product_detail', slug=slug)
        if not comment:
            messages.error(req, 'Please enter review text.'); return redirect('store:product_detail', slug=slug)
        if image and image.size > 5 * 1024 * 1024:
            messages.error(req, 'Review photos must be 5 MB or smaller.'); return redirect('store:product_detail', slug=slug)
        review, _ = Review.objects.update_or_create(user=req.user, product=product, defaults={'rating': rating_value, 'comment': comment})
        if image:
            try:
                from PIL import Image
                from io import BytesIO
                src = Image.open(image).convert('RGB')
                target_w, target_h = 350, 450
                src_ratio, target_ratio = src.width / src.height, target_w / target_h
                if src_ratio > target_ratio:
                    new_w = int(src.height * target_ratio); left = (src.width - new_w) // 2; src = src.crop((left, 0, left + new_w, src.height))
                else:
                    new_h = int(src.width / target_ratio); top = (src.height - new_h) // 2; src = src.crop((0, top, src.width, top + new_h))
                src = src.resize((target_w, target_h), Image.Resampling.LANCZOS)
                out = BytesIO(); src.save(out, format='JPEG', quality=88, optimize=True)
                photo_bytes = out.getvalue()

                # Store the processed review photo in Supabase Storage instead of
                # Railway/local media. The bucket is the existing public `review` bucket.
                supabase = get_supabase_client()
                bucket_name = 'review'
                storage_path = f"reviews/{req.user.id}/review_{product.id}_{uuid.uuid4().hex}.jpg"
                supabase.storage.from_(bucket_name).upload(
                    storage_path,
                    photo_bytes,
                    {
                        'content-type': 'image/jpeg',
                        'cache-control': '31536000',
                        'upsert': 'true',
                    }
                )
                public_url = supabase.storage.from_(bucket_name).get_public_url(storage_path)
                review.review_image_url = str(public_url)
                review.save(update_fields=['review_image_url'])
            except Exception as exc:
                logging.exception('Review photo upload failed: %s', exc)
                messages.error(req, 'The review photo could not be processed. Please upload a valid image.'); return redirect('store:product_detail', slug=slug)
        messages.success(req, '✅ Review submitted!'); return redirect('store:product_detail', slug=slug)

    return render(req, 'store/product_detail.html', {'product': product, 'seller_prof': seller_prof, 'related_products': related_products, 'reviews': reviews, 'conversation': conversation, 'can_chat': bool(product.seller) and (not req.user.is_authenticated or product.seller.user_id != req.user.id), 'seller_name': seller_prof.get('store_name') if seller_prof else getattr(product.seller, 'store_name', 'Seller')})


@login_required
def add_review(req, product_id):
    """Handle review submission via POST"""
    if req.method != "POST":
        return redirect("store:home")
    
    product = get_object_or_404(Product, id=product_id, is_active=True)
    rating = req.POST.get("rating")
    comment = req.POST.get("comment", "").strip()
    
    if rating and rating.isdigit():
        # Create or update review (one review per user per product)
        Review.objects.update_or_create(
            user=req.user,
            product=product,
            defaults={
                "rating": int(rating),
                "comment": comment
            }
        )
        messages.success(req, "✅ Review submitted successfully!")
    
    return redirect("store:product_detail", slug=product.slug)


@login_required
def remove_from_cart(req, product_id):
    """Remove product from cart"""
    cart = req.session.get('cart', {})
    product_id_str = str(product_id)
    
    if product_id_str in cart:
        del cart[product_id_str]
        req.session['cart'] = cart
        req.session.modified = True
        messages.success(req, "✅ Item removed from cart")

        try:
            product = Product.objects.get(id=product_id)
            _sync_own_db_cart(req.user, product, remove=True)
        except Product.DoesNotExist:
            pass
    
    return redirect('store:cart')


def is_seller_or_staff(user):
    return user.is_staff or hasattr(user, 'seller_profile')

def is_seller_or_staff(user):
    return user.is_staff or hasattr(user, 'seller_profile')

@login_required
@user_passes_test(is_seller_or_staff)
def analytics_dashboard(req):
    """Analytics dashboard with accurate metrics and chart data"""
    
    is_staff = req.user.is_staff
    
    # ✅ ADD THIS: Fetch pending sellers (only for admins/staff)
    pending_sellers = SellerProfile.objects.filter(status='pending').select_related('user').order_by('-created_at') if is_staff else []
    
    # ✅ Build base Q filters (no kwargs mixed in)
    if is_staff:
        order_q = Q(payment_status='paid')
        product_q = Q(is_active=True)
    else:
        seller = req.user.seller_profile
        order_q = Q(items__product__seller=seller, payment_status='paid')
        product_q = Q(seller=seller, is_active=True)
    
    now = timezone.now()
    today_start = now.replace(hour=0, minute=0, second=0, microsecond=0)
    week_start = now - timedelta(days=7)
    
    # 📊 Orders Today
    orders_q = order_q & Q(created_at__gte=today_start)
    orders_today = Order.objects.filter(orders_q).distinct().count()
    
    # 📊 Revenue Today
    revenue_today = Order.objects.filter(orders_q).aggregate(total=Sum('total_amount'))['total'] or 0
    
    # 📊 New Users Today
    new_users_today = User.objects.filter(
        date_joined__gte=today_start,
        is_staff=False
    ).count()
    
    # 📊 Page Views
    try:
        from .models import PageView
        page_views_today = PageView.objects.filter(timestamp__gte=today_start).count()
    except ImportError:
        page_views_today = 0
    
    # 📈 Hourly Chart Data (last 24h)
    hourly_q = order_q & Q(created_at__gte=now - timedelta(hours=24))
    hourly_data = Order.objects.filter(hourly_q).annotate(
        hour=TruncHour('created_at')
    ).values('hour').annotate(
        revenue=Sum('total_amount'),
        orders=Count('id', distinct=True)
    ).order_by('hour')
    
    hourly_labels, hourly_revenue, hourly_orders = [], [], []
    for i in range(24):
        hour_dt = now - timedelta(hours=23-i)
        hourly_labels.append(hour_dt.strftime('%H:00'))
        match = next((h for h in hourly_data if h['hour'] == hour_dt.replace(minute=0, second=0, microsecond=0)), None)
        hourly_revenue.append(float(match['revenue'] or 0) if match else 0)
        hourly_orders.append(match['orders'] if match else 0)
    
    # 📈 Daily Chart Data (last 7 days)
    daily_q = order_q & Q(created_at__gte=week_start)
    daily_data = Order.objects.filter(daily_q).annotate(
        day=TruncDay('created_at')
    ).values('day').annotate(
        revenue=Sum('total_amount'),
        orders=Count('id', distinct=True)
    ).order_by('day')
    
    daily_labels, daily_revenue = [], []
    for i in range(7):
        day_dt = week_start + timedelta(days=i)
        daily_labels.append(day_dt.strftime('%a %d'))
        match = next((d for d in daily_data if d['day'].date() == day_dt.date()), None)
        daily_revenue.append(float(match['revenue'] or 0) if match else 0)
    
    # 🏆 Top Products This Week

# ✅ Build product filters using relationship paths for OrderItem queries
    if is_staff:
        # Staff: filter by active products only
        order_item_filters = Q(
            order__payment_status='paid',
            product__is_active=True,
            order__created_at__gte=week_start
        )
    else:
        # Seller: filter by their active products only
        seller = req.user.seller_profile
        order_item_filters = Q(
            order__payment_status='paid',
            product__seller=seller,      # 🔑 Use product__seller
            product__is_active=True,     # 🔑 Use product__is_active
            order__created_at__gte=week_start
        )

    # ✅ Top Products query with correct field paths
    top_products = OrderItem.objects.filter(
        order_item_filters
    ).values(
        'product__name',
        'product__id'
    ).annotate(
        revenue=Sum('subtotal'),
        sold=Sum('quantity')
    ).order_by('-revenue')[:5]
    
    context = {
        'orders_today': orders_today,
        'revenue_today': float(revenue_today),
        'new_users_today': new_users_today,
        'page_views_today': page_views_today,
        'hourly_labels': hourly_labels,
        'hourly_revenue': hourly_revenue,
        'hourly_orders': hourly_orders,
        'daily_labels': daily_labels,
        'daily_revenue': daily_revenue,
        'top_products': list(top_products),
        'is_staff': is_staff,
        'last_updated': now.strftime('%Y-%m-%d %H:%M:%S'),
        'pending_sellers': pending_sellers,
    }
    
    return render(req, 'store/analytics_dashboard.html', context)

@staff_member_required
def analytics_api(req):
    """API endpoint for real-time analytics data"""
    now = timezone.now()
    today = now.date()
    last_7_days = today - timedelta(days=7)
    last_30_days = today - timedelta(days=30)
    
    # 📊 Revenue Metrics
    revenue_today = Order.objects.filter(
        created_at__date=today, payment_status='paid'
    ).aggregate(total=Sum('total_amount'))['total'] or 0
    
    revenue_week = Order.objects.filter(
        created_at__date__gte=last_7_days, payment_status='paid'
    ).aggregate(total=Sum('total_amount'))['total'] or 0
    
    revenue_month = Order.objects.filter(
        created_at__date__gte=last_30_days, payment_status='paid'
    ).aggregate(total=Sum('total_amount'))['total'] or 0
    
    # 📦 Order Metrics
    orders_today = Order.objects.filter(created_at__date=today).count()
    orders_week = Order.objects.filter(created_at__date__gte=last_7_days).count()
    
    # 👥 User Metrics
    new_users_today = User.objects.filter(date_joined__date=today).count()
    total_users = User.objects.count()
    
    # 🛍️ Product Metrics
    top_products = OrderItem.objects.filter(
        order__created_at__date__gte=last_7_days
    ).values('product__name').annotate(
        total_sold=Sum('quantity'),
        revenue=Sum('subtotal')
    ).order_by('-total_sold')[:5]
    
    # 📈 Hourly Sales (last 24 hours)
    hourly_sales = []
    for hour in range(24):
        start = now.replace(hour=hour, minute=0, second=0, microsecond=0)
        end = start + timedelta(hours=1)
        sales = Order.objects.filter(
            created_at__gte=start, created_at__lt=end, payment_status='paid'
        ).aggregate(total=Sum('total_amount'))['total'] or 0
        hourly_sales.append({
            'hour': f"{hour:02d}:00",
            'sales': float(sales)
        })
    
    # 🌍 Page Views (last hour)
    views_last_hour = PageView.objects.filter(
        timestamp__gte=now - timedelta(hours=1)
    ).count()
    
    return JsonResponse({
        'revenue': {
            'today': float(revenue_today),
            'week': float(revenue_week),
            'month': float(revenue_month)
        },
        'orders': {
            'today': orders_today,
            'week': orders_week
        },
        'users': {
            'new_today': new_users_today,
            'total': total_users
        },
        'top_products': list(top_products),
        'hourly_sales': hourly_sales,
        'page_views_last_hour': views_last_hour,
        'timestamp': now.isoformat()
    })


def forgot_password(req):
    """Step 1: Send password reset email via Supabase"""
    if req.user.is_authenticated:
        return redirect('store:home')
        
    if req.method == 'POST':
        email = req.POST.get('email', '').strip()
        if not email:
            messages.error(req, "Please enter your email address.")
        else:
            try:
                supabase = get_supabase_client()
                redirect_url = req.build_absolute_uri(reverse('store:password_reset'))
                
                # ✅ Python SDK uses snake_case + options dict
                supabase.auth.reset_password_for_email(email, options={"redirectTo": redirect_url})
                
                messages.success(req, f"✅ Reset link sent to {email}. Check your inbox (and spam folder).")
                return redirect('store:login')
                
            except Exception as e:
                print(f"🔴 SUPABASE RESET ERROR: {type(e).__name__} - {str(e)}")
                messages.error(req, "❌ Failed to send reset email. Please try again.")
                
    return render(req, 'store/forgot_password.html')

def password_reset(req):
    """Display the password reset page."""
    return render(req, 'store/reset_password.html')

@require_POST
def api_reset_password(req):
    """API: Update password using Supabase recovery token"""
    try:
        data = json.loads(req.body)
        token = data.get('token')
        new_password = data.get('password')
        
        if not token or not new_password:
            return JsonResponse({'error': 'Missing token or password'}, status=400)
            
        if len(new_password) < 8:
            return JsonResponse({'error': 'Password must be at least 8 characters'}, status=400)
            
        # Call Supabase Auth API directly with the recovery token
        headers = {
            "Authorization": f"Bearer {token}",
            "apikey": settings.SUPABASE_ANON_KEY,
            "Content-Type": "application/json"
        }
        
        resp = requests.put(
            f"{settings.SUPABASE_URL}/auth/v1/user",
            json={"password": new_password},
            headers=headers,
            timeout=10
        )
        resp.raise_for_status()
        
        return JsonResponse({'success': True, 'message': 'Password updated successfully'})
        
    except requests.exceptions.HTTPError as e:
        error_msg = "Invalid or expired reset link. Please request a new one."
        try:
            error_data = e.response.json()
            if "Token is expired" in error_data.get("message", ""):
                error_msg = "Reset link has expired. Please request a new one."
        except: pass
        return JsonResponse({'error': error_msg}, status=401)
    except Exception as e:
        return JsonResponse({'error': 'An unexpected error occurred. Please try again.'}, status=500)

# Middleware to track page views (optional but recommended)
class AnalyticsMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response
        
    def __call__(self, request):
        response = self.get_response(request)
        
        # Track page views for analytics (skip static/media/admin)
        if not request.path.startswith(('/static/', '/media/', '/admin/', '/api/')):
            PageView.objects.create(
                user=request.user if request.user.is_authenticated else None,
                path=request.path,
                session_key=request.session.session_key or ''
            )
        return response
    
# store/views.py


# store/views.py

@login_required
def seller_daily_sales_api(req):
    """API: Returns last 7 days of daily sales broken down by product"""
    try:
        seller = req.user.seller_profile
    except SellerProfile.DoesNotExist:
        return JsonResponse({"labels": [], "datasets": []})

    start_date = timezone.now() - timedelta(days=7)
    
    # Get seller's active products for consistent color mapping
    products = Product.objects.filter(seller=seller, is_active=True).order_by('name')
    product_ids = {p.id: p.name for p in products}
    
    # Aggregate daily sales PER PRODUCT for paid orders
    daily_product_sales = OrderItem.objects.filter(
        product__seller=seller,
        product__in=products,
        order__payment_status='paid',
        order__created_at__gte=start_date
    ).annotate(
        day=TruncDay('order__created_at')
    ).values('day', 'product_id').annotate(
        total=Sum('subtotal'),
        quantity=Sum('quantity')
    ).order_by('day', 'product_id')

    # Structure data for Chart.js multi-dataset
    days = {}
    for item in daily_product_sales:
        day_key = item['day'].strftime('%a %d')  # e.g., "Mon 05"
        if day_key not in days:
            days[day_key] = {}
        days[day_key][item['product_id']] = {
            'total': float(item['total'] or 0),
            'quantity': item['quantity'] or 0
        }

    # Build datasets array (one per product)
    datasets = []
    for pid, pname in product_ids.items():
        data = []
        for day_key in sorted(days.keys()):
            val = days[day_key].get(pid, {}).get('total', 0)
            data.append(val)
        
        # Skip products with zero sales in the period
        if any(v > 0 for v in data):
            datasets.append({
                'label': pname,
                'data': data,
                'productId': pid,  # For legend toggle
                'backgroundColor': '',  # Will be set by JS theme handler
                'borderColor': '',
                'borderWidth': 1
            })

    return JsonResponse({
        'labels': sorted(days.keys()),
        'datasets': datasets,
        'products': [{'id': pid, 'name': name} for pid, name in product_ids.items()]
    })


def is_admin(user): return user.is_staff or user.is_superuser

@login_required
@user_passes_test(is_admin)
@require_POST
def approve_seller(request, seller_id):
    seller = get_object_or_404(SellerProfile, id=seller_id, status='pending')
    seller.status = 'approved'
    seller.is_verified = True
    seller.verified_at = timezone.now()
    seller.save()
    
    # Clear related notifications
    AdminNotification.objects.filter(link__contains=str(seller_id)).update(is_read=True)
    messages.success(request, f"✅ '{seller.store_name}' has been approved.")
    return redirect(request.META.get('HTTP_REFERER', 'store:admin_dashboard'))

@login_required
@user_passes_test(is_admin)
@require_POST
def reject_seller(request, seller_id):
    seller = get_object_or_404(SellerProfile, id=seller_id, status='pending')
    reason = request.POST.get('reason', 'No reason provided').strip()
    
    seller.status = 'rejected'
    seller.is_verified = False
    seller.rejected_reason = reason
    seller.save()
    
    AdminNotification.objects.filter(link__contains=str(seller_id)).update(is_read=True)
    messages.warning(request, f"❌ '{seller.store_name}' has been rejected.")
    return redirect(request.META.get('HTTP_REFERER', 'store:admin_dashboard'))

def is_admin(user): return user.is_staff or user.is_superuser

@login_required
@user_passes_test(is_admin)
def mark_notifications_read(request):
    AdminNotification.objects.filter(is_read=False).update(is_read=True)
    return redirect(request.META.get('HTTP_REFERER', 'store:home'))


def is_admin(user): return user.is_staff or user.is_superuser

@login_required
def mark_user_notifications_read(request):
    UserNotification.objects.filter(user=request.user, is_read=False).update(is_read=True)
    return redirect(request.META.get('HTTP_REFERER', 'store:home'))

@login_required
@user_passes_test(is_admin)
def seller_application_detail(request, seller_id):
    """Display seller application details with approve/reject actions"""
    seller = get_object_or_404(SellerProfile, id=seller_id)
    
    # Mark this notification as read if it exists
    AdminNotification.objects.filter(link__contains=f'seller/{seller_id}').update(is_read=True)
    
    if request.method == 'POST':
        action = request.POST.get('action')
        reason = request.POST.get('reason', '').strip()
        
        if action == 'approve':
            seller.status = 'approved'
            seller.is_verified = True
            seller.verified_at = timezone.now()
            seller.save()
            messages.success(request, f"✅ '{seller.store_name}' has been APPROVED. User is now a seller.")
            
        elif action == 'reject':
            seller.status = 'rejected'
            seller.is_verified = False
            seller.rejected_reason = reason
            seller.save()
            messages.warning(request, f"❌ '{seller.store_name}' has been REJECTED.")
        
        return redirect('store:admin_dashboard')
    
    return render(request, 'store/seller_application_detail.html', {'seller': seller})

# ============================================================================
# COMMUNITY HIGHLIGHTS — proof-of-purchase feed & automated engagement rewards
# ============================================================================
#
# Buyers with a paid + delivered order post an unboxing highlight. Shoppers
# engage, and every interaction scores the post:
#
#       Like +1        Comment +2        Share +3
#
# Each seller sets a points goal (default 15) and a discount percentage. The
# moment a highlight crosses the goal, a unique voucher is minted and dropped
# into the buyer's wallet, and both sides get a notification.
# ----------------------------------------------------------------------------

from .models import (
    CommunityHighlight, HighlightEngagement, HighlightComment,
    DiscountVoucher, SellerHighlightGoal,
    SellerFollow,
)

HIGHLIGHT_MEDIA_BUCKET = "review"
HIGHLIGHT_MAX_UPLOAD = 25 * 1024 * 1024  # 25 MB
HIGHLIGHT_VIDEO_TYPES = {"video/mp4", "video/webm", "video/quicktime"}


def _highlight_feed_queryset():
    return (
        CommunityHighlight.objects
        .filter(is_active=True, is_approved=True)
        .select_related("buyer", "buyer__user_profile", "product", "seller",
                        "seller__user", "order", "voucher")
        .prefetch_related("comments__user")
    )


def _upload_highlight_media(user, upload):
    """Push the buyer's unboxing photo/clip to Supabase Storage.

    Photos are re-encoded to a sane feed width; videos are stored as-is.
    Returns (public_url, storage_path, media_type) or raises."""
    content_type = (getattr(upload, "content_type", "") or "").lower()
    is_video = content_type in HIGHLIGHT_VIDEO_TYPES

    supabase = get_supabase_client()

    if is_video:
        payload = upload.read()
        extension = "mp4" if "mp4" in content_type else content_type.split("/")[-1]
        storage_path = f"highlights/{user.id}/hl_{uuid.uuid4().hex}.{extension}"
        upload_content_type = content_type
        media_type = CommunityHighlight.MEDIA_VIDEO
    else:
        from PIL import Image
        from io import BytesIO

        src = Image.open(upload).convert("RGB")
        max_width = 1200
        if src.width > max_width:
            ratio = max_width / src.width
            src = src.resize((max_width, int(src.height * ratio)), Image.Resampling.LANCZOS)
        buffer = BytesIO()
        src.save(buffer, format="JPEG", quality=86, optimize=True)
        payload = buffer.getvalue()
        storage_path = f"highlights/{user.id}/hl_{uuid.uuid4().hex}.jpg"
        upload_content_type = "image/jpeg"
        media_type = CommunityHighlight.MEDIA_IMAGE

    supabase.storage.from_(HIGHLIGHT_MEDIA_BUCKET).upload(
        storage_path,
        payload,
        {
            "content-type": upload_content_type,
            "cache-control": "31536000",
            "upsert": "true",
        },
    )
    public_url = supabase.storage.from_(HIGHLIGHT_MEDIA_BUCKET).get_public_url(storage_path)
    return str(public_url), storage_path, media_type


def _notify_reward_unlocked(highlight, voucher):
    """Tell the buyer their voucher landed, and let the seller know too."""
    UserNotification.objects.create(
        user=highlight.buyer,
        title="🎁 Reward unlocked!",
        message=(
            f"Your highlight reached {highlight.total_points} points. "
            f"Voucher {voucher.code} ({voucher.discount_percent}% off) is in your wallet."
        ),
        link=reverse("store:my_vouchers"),
    )
    if highlight.seller and highlight.seller.user:
        UserNotification.objects.create(
            user=highlight.seller.user,
            title="🔥 A highlight hit your goal",
            message=(
                f"{highlight.buyer.username}'s unboxing of {highlight.product.name} "
                f"reached {highlight.points_goal} points. "
                f"A {voucher.discount_percent}% voucher was issued."
            ),
            link=reverse("store:highlight_detail", args=[highlight.id]),
        )


def _award_points(highlight, user, action):
    """Score an interaction, respecting the anti-gaming rules.

    Returns (awarded: bool, voucher_or_None). Authors never score their own
    posts, and each user can only score a given action once per highlight."""
    if not user.is_authenticated or user == highlight.buyer:
        return False, None

    _, created = HighlightEngagement.objects.get_or_create(
        highlight=highlight,
        user=user,
        action=action,
        defaults={"points": HighlightEngagement.POINT_VALUES.get(action, 0)},
    )
    if not created:
        return False, None

    highlight.recalculate()
    voucher = highlight.maybe_unlock_reward()
    if voucher:
        _notify_reward_unlocked(highlight, voucher)
    return True, voucher


def _highlight_payload(highlight, user=None):
    """Consistent JSON the feed's JS uses to repaint a card after an action."""
    liked = False
    if user and user.is_authenticated:
        liked = HighlightEngagement.objects.filter(
            highlight=highlight, user=user, action=HighlightEngagement.LIKE
        ).exists()
    voucher = getattr(highlight, "voucher", None)
    return {
        "id": highlight.id,
        "points": highlight.total_points,
        "goal": highlight.points_goal,
        "progress": highlight.progress_percent,
        "remaining": highlight.points_remaining,
        "likes": highlight.like_count,
        "comments": highlight.comment_count,
        "shares": highlight.share_count,
        "liked": liked,
        "unlocked": highlight.reward_unlocked,
        "voucher_code": voucher.code if voucher else "",
        "discount_percent": highlight.discount_percent,
    }


# ──────────────────────────── FEED ────────────────────────────

def community_highlights(req):
    """The public Community Highlights feed."""
    tab = req.GET.get("tab", "all")
    highlights = _highlight_feed_queryset()

    if tab == "engaged":
        highlights = highlights.order_by("-total_points", "-created_at")
    elif tab == "unlocked":
        highlights = highlights.filter(reward_unlocked=True)
    elif tab == "mine" and req.user.is_authenticated:
        highlights = highlights.filter(buyer=req.user)
    else:
        tab = "all"

    paginator = Paginator(highlights, 8)
    page = paginator.get_page(req.GET.get("page"))

    # Which of these has the viewer already liked? One query, not N.
    liked_ids = set()
    if req.user.is_authenticated:
        liked_ids = set(
            HighlightEngagement.objects
            .filter(user=req.user, action=HighlightEngagement.LIKE,
                    highlight__in=[h.id for h in page])
            .values_list("highlight_id", flat=True)
        )

    eligible_items, my_vouchers = [], []
    if req.user.is_authenticated:
        eligible_items = list(CommunityHighlight.eligible_order_items(req.user)[:40])
        my_vouchers = list(
            DiscountVoucher.objects.filter(buyer=req.user, is_used=False)
            .select_related("seller")[:5]
        )

    return render(req, "store/community_highlights.html", {
        "highlights": page,
        "page_obj": page,
        "tab": tab,
        "liked_ids": liked_ids,
        "eligible_items": eligible_items,
        "my_vouchers": my_vouchers,
        "total_count": _highlight_feed_queryset().count(),
        "point_values": HighlightEngagement.POINT_VALUES,
    })


def highlight_detail(req, highlight_id):
    """Single highlight — this is what a shared link opens."""
    highlight = get_object_or_404(_highlight_feed_queryset(), id=highlight_id)

    # The card partial is shared with the feed, so hand it the same shape.
    liked_ids = set()
    if req.user.is_authenticated and HighlightEngagement.objects.filter(
        highlight=highlight, user=req.user, action=HighlightEngagement.LIKE
    ).exists():
        liked_ids = {highlight.id}

    return render(req, "store/highlight_detail.html", {
        "highlight": highlight,
        "liked_ids": liked_ids,
        "point_values": HighlightEngagement.POINT_VALUES,
    })


# ──────────────────────── POSTING & EDITING ────────────────────────

@login_required
@require_POST
def create_highlight(req):
    """Post an unboxing highlight. Only ever possible against a real,
    paid-and-delivered order item belonging to the poster."""
    order_item_id = req.POST.get("order_item")
    title = (req.POST.get("title") or "").strip()
    body = (req.POST.get("body") or "").strip()
    media = req.FILES.get("media")

    if not (order_item_id and title and body):
        messages.error(req, "Pick the item you're reviewing and add a title and story.")
        return redirect("store:community_highlights")

    order_item = (
        CommunityHighlight.eligible_order_items(req.user)
        .filter(id=order_item_id).first()
    )
    if not order_item:
        messages.error(
            req,
            "That item isn't eligible. Highlights are only for paid orders "
            "that have been delivered, and each item can be featured once."
        )
        return redirect("store:community_highlights")

    if media and media.size > HIGHLIGHT_MAX_UPLOAD:
        messages.error(req, "Photos and clips must be 25 MB or smaller.")
        return redirect("store:community_highlights")

    seller = order_item.product.seller
    goal = SellerHighlightGoal.for_seller(seller)

    media_url, storage_path, media_type = "", "", CommunityHighlight.MEDIA_IMAGE
    if media:
        try:
            media_url, storage_path, media_type = _upload_highlight_media(req.user, media)
        except Exception as exc:
            logging.exception("Highlight media upload failed: %s", exc)
            messages.error(req, "We couldn't process that file. Try another photo or clip.")
            return redirect("store:community_highlights")

    try:
        highlight = CommunityHighlight.objects.create(
            buyer=req.user,
            order=order_item.order,
            order_item=order_item,
            product=order_item.product,
            seller=seller,
            title=title[:160],
            body=body[:2000],
            media_url=media_url,
            media_type=media_type,
            media_storage_path=storage_path,
            points_goal=goal.points_goal if goal else 15,
            discount_percent=goal.discount_percent if goal else 10,
        )
    except IntegrityError:
        messages.error(req, "You've already posted a highlight for that item.")
        return redirect("store:community_highlights")

    if seller and seller.user:
        UserNotification.objects.create(
            user=seller.user,
            title="📸 New unboxing highlight",
            message=f"{req.user.username} posted an unboxing of {highlight.product.name}.",
            link=reverse("store:highlight_detail", args=[highlight.id]),
        )

    messages.success(
        req,
        f"✅ Highlight posted! Reach {highlight.points_goal} points to unlock "
        f"{highlight.discount_percent}% off from this seller."
    )
    return redirect("store:highlight_detail", highlight_id=highlight.id)


@login_required
@require_POST
def edit_highlight(req, highlight_id):
    """Authors can fix up their own words and swap the media."""
    highlight = get_object_or_404(CommunityHighlight, id=highlight_id, buyer=req.user)
    title = (req.POST.get("title") or "").strip()
    body = (req.POST.get("body") or "").strip()
    if not (title and body):
        messages.error(req, "A highlight needs both a title and a story.")
        return redirect("store:highlight_detail", highlight_id=highlight.id)

    highlight.title = title[:160]
    highlight.body = body[:2000]

    media = req.FILES.get("media")
    if media:
        if media.size > HIGHLIGHT_MAX_UPLOAD:
            messages.error(req, "Photos and clips must be 25 MB or smaller.")
            return redirect("store:highlight_detail", highlight_id=highlight.id)
        try:
            highlight.media_url, highlight.media_storage_path, highlight.media_type = \
                _upload_highlight_media(req.user, media)
        except Exception as exc:
            logging.exception("Highlight media replace failed: %s", exc)
            messages.error(req, "We couldn't process that file.")
            return redirect("store:highlight_detail", highlight_id=highlight.id)

    highlight.save(update_fields=[
        "title", "body", "media_url", "media_storage_path", "media_type", "updated_at"
    ])
    messages.success(req, "✅ Highlight updated.")
    return redirect("store:highlight_detail", highlight_id=highlight.id)


@login_required
@require_POST
def delete_highlight(req, highlight_id):
    """Authors (and staff) can pull a highlight down. Any voucher already
    unlocked stays valid — the buyer earned it."""
    highlight = get_object_or_404(CommunityHighlight, id=highlight_id)
    if highlight.buyer != req.user and not req.user.is_staff:
        messages.error(req, "You can only delete your own highlights.")
        return redirect("store:community_highlights")

    DiscountVoucher.objects.filter(highlight=highlight).update(highlight=None)
    if highlight.media_storage_path:
        try:
            get_supabase_client().storage.from_(HIGHLIGHT_MEDIA_BUCKET).remove(
                [highlight.media_storage_path]
            )
        except Exception:
            pass
    highlight.delete()
    messages.success(req, "Highlight deleted.")
    return redirect("store:community_highlights")


# ──────────────────────── ENGAGEMENT (AJAX) ────────────────────────

@login_required
@require_POST
def toggle_highlight_like(req, highlight_id):
    """+1 point on the first like. Un-liking takes the point back."""
    highlight = get_object_or_404(CommunityHighlight, id=highlight_id, is_active=True)

    if req.user == highlight.buyer:
        return JsonResponse(
            {"ok": False, "error": "Your own highlight can't earn points from you."},
            status=400,
        )

    existing = HighlightEngagement.objects.filter(
        highlight=highlight, user=req.user, action=HighlightEngagement.LIKE
    ).first()

    if existing:
        existing.delete()
        highlight.recalculate()
        payload = _highlight_payload(highlight, req.user)
        payload.update(ok=True, awarded=0)
        return JsonResponse(payload)

    _, voucher = _award_points(highlight, req.user, HighlightEngagement.LIKE)
    payload = _highlight_payload(highlight, req.user)
    payload.update(
        ok=True,
        awarded=HighlightEngagement.POINT_VALUES[HighlightEngagement.LIKE],
        just_unlocked=bool(voucher),
    )
    return JsonResponse(payload)


@login_required
@require_POST
def add_highlight_comment(req, highlight_id):
    """+2 points, but only for a user's first comment on the highlight."""
    highlight = get_object_or_404(CommunityHighlight, id=highlight_id, is_active=True)
    body = (req.POST.get("body") or "").strip()
    if not body:
        return JsonResponse({"ok": False, "error": "Write something first."}, status=400)

    comment = HighlightComment.objects.create(
        highlight=highlight, user=req.user, body=body[:600]
    )
    awarded, voucher = _award_points(highlight, req.user, HighlightEngagement.COMMENT)
    highlight.recalculate()

    payload = _highlight_payload(highlight, req.user)
    payload.update(
        ok=True,
        awarded=HighlightEngagement.POINT_VALUES[HighlightEngagement.COMMENT] if awarded else 0,
        just_unlocked=bool(voucher),
        comment={
            "user": req.user.username,
            "avatar": req.user.user_profile.get_avatar_url(),
            "body": comment.body,
            "when": "just now",
        },
    )
    return JsonResponse(payload)


@login_required
@require_POST
def share_highlight(req, highlight_id):
    """+3 points for a user's first share. Returns the link to copy."""
    highlight = get_object_or_404(CommunityHighlight, id=highlight_id, is_active=True)
    awarded, voucher = _award_points(highlight, req.user, HighlightEngagement.SHARE)

    payload = _highlight_payload(highlight, req.user)
    payload.update(
        ok=True,
        awarded=HighlightEngagement.POINT_VALUES[HighlightEngagement.SHARE] if awarded else 0,
        just_unlocked=bool(voucher),
        share_url=req.build_absolute_uri(
            reverse("store:highlight_detail", args=[highlight.id])
        ),
    )
    return JsonResponse(payload)


# ──────────────────────── SELLER GOAL & VOUCHERS ────────────────────────

@login_required
@require_POST
def set_highlight_goal(req):
    """Seller sets the points target and the discount it unlocks."""
    seller = get_object_or_404(SellerProfile, user=req.user)
    goal = SellerHighlightGoal.for_seller(seller)

    try:
        points_goal = int(req.POST.get("points_goal", goal.points_goal))
        discount_percent = int(req.POST.get("discount_percent", goal.discount_percent))
        validity = int(req.POST.get("voucher_validity_days", goal.voucher_validity_days))
    except (TypeError, ValueError):
        messages.error(req, "Please enter whole numbers for the goal and discount.")
        return redirect("store:seller_dashboard")

    if not 1 <= points_goal <= 10000:
        messages.error(req, "The points goal must be between 1 and 10,000.")
        return redirect("store:seller_dashboard")
    if not 1 <= discount_percent <= 90:
        messages.error(req, "The discount must be between 1% and 90%.")
        return redirect("store:seller_dashboard")
    if not 1 <= validity <= 365:
        messages.error(req, "Voucher validity must be between 1 and 365 days.")
        return redirect("store:seller_dashboard")

    goal.points_goal = points_goal
    goal.discount_percent = discount_percent
    goal.voucher_validity_days = validity
    goal.is_active = req.POST.get("is_active") == "on"
    goal.save()

    messages.success(
        req,
        f"✅ Goal saved: {points_goal} points unlocks {discount_percent}% off "
        f"for the buyer, valid {validity} days."
    )
    return redirect("store:seller_dashboard")


@login_required
def my_vouchers(req):
    """The buyer's voucher wallet."""
    vouchers = (
        DiscountVoucher.objects
        .filter(buyer=req.user)
        .select_related("seller", "highlight", "highlight__product")
    )
    return render(req, "store/my_vouchers.html", {
        "vouchers": vouchers,
        "active_count": sum(1 for v in vouchers if v.is_redeemable),
    })


@login_required
@require_POST
def validate_voucher(req):
    """Check a code and return the cedi discount for a given subtotal.

    Used by the checkout page; also safe to call from anywhere else."""
    code = (req.POST.get("code") or "").strip().upper()
    try:
        subtotal = Decimal(str(req.POST.get("subtotal") or "0"))
    except Exception:
        subtotal = Decimal("0")

    voucher = DiscountVoucher.objects.filter(code=code, buyer=req.user).first()
    if not voucher:
        return JsonResponse({"ok": False, "error": "That code isn't in your wallet."}, status=404)
    if voucher.is_used:
        return JsonResponse({"ok": False, "error": "This voucher has already been used."}, status=400)
    if voucher.is_expired:
        return JsonResponse({"ok": False, "error": "This voucher has expired."}, status=400)

    discount = voucher.discount_for(subtotal)
    req.session["applied_voucher"] = voucher.code
    req.session.modified = True
    return JsonResponse({
        "ok": True,
        "code": voucher.code,
        "discount_percent": voucher.discount_percent,
        "discount_amount": str(discount),
        "new_total": str((subtotal - discount).quantize(Decimal("0.01"))),
        "seller": voucher.seller.store_name if voucher.seller else "",
    })

def _consume_applied_voucher(req, order):
    """Burn the Community Highlights voucher the buyer applied at checkout.

    Called once the order exists. Silent on failure: a payment must never be
    lost over voucher bookkeeping."""
    code = req.session.pop('applied_voucher', None)
    if not code:
        return
    req.session.modified = True
    try:
        voucher = DiscountVoucher.objects.filter(
            code=code, buyer=order.user, is_used=False
        ).first()
        if voucher:
            voucher.mark_used(order)
    except Exception as exc:
        logging.exception('Voucher redemption bookkeeping failed: %s', exc)


# ==================== SELLER STOREFRONT & FOLLOWING ====================

def seller_store(req, seller_id):
    seller = get_object_or_404(
        SellerProfile.objects.select_related('user'), id=seller_id)
    products = (Product.objects
                .filter(seller=seller, is_active=True)
                .select_related('category')
                .order_by('-created_at'))
    is_following = (req.user.is_authenticated and
                    SellerFollow.objects.filter(buyer=req.user, seller=seller).exists())
    return render(req, 'store/seller_store.html', {
        'seller': seller,
        'products': products,
        'is_following': is_following,
        'follower_count': seller.followers.count(),
        'product_count': products.count(),
    })


@login_required
@require_POST
def toggle_follow(req, seller_id):
    seller = get_object_or_404(SellerProfile, id=seller_id)
    if seller.user_id == req.user.id:
        return JsonResponse({'success': False,
                             'error': 'You cannot follow your own store.'}, status=400)
    follow, created = SellerFollow.objects.get_or_create(buyer=req.user, seller=seller)
    if not created:
        follow.delete()
    return JsonResponse({'success': True, 'following': created,
                         'followers': seller.followers.count()})


# ==================== IN-SITE BUYER ↔ SELLER CHAT ====================
# Replaces the old WhatsApp hand-off. Threads are private to the two
# participants, the buyer shares a location so the seller can quote delivery,
# the price is negotiable, and the seller closes with an invoice that becomes
# the amount actually charged at checkout.

def _get_conversation_or_404(user, conversation_id):
    conv = get_object_or_404(
        Conversation.objects.select_related('product', 'buyer', 'seller', 'seller__user'),
        id=conversation_id)
    if not conv.is_participant(user):
        # 404 rather than 403: a non-participant should not learn the thread exists.
        raise Http404('Conversation not found.')
    return conv


def _chat_message_payload(msg, viewer):
    invoice = msg.invoice
    return {
        'id': msg.id,
        'kind': msg.kind,
        'body': msg.body if not msg.is_deleted else '',
        'deleted': bool(msg.is_deleted),
        'mine': bool(msg.sender_id and msg.sender_id == viewer.id),
        'sender': msg.sender.username if msg.sender else 'System',
        'created_at': timezone.localtime(msg.created_at).strftime('%d %b, %H:%M'),
        # Sent = one tick; viewed by the other participant = two ticks.
        'is_read': bool(msg.is_read),
        'invoice': {
            'id': invoice.id,
            'product': invoice.product.name,
            'quantity': invoice.quantity,
            'unit_price': str(invoice.unit_price),
            'items_total': str(invoice.items_total),
            'delivery_fee': str(invoice.delivery_fee),
            'total': str(invoice.total),
            'note': invoice.note,
            'status': invoice.status,
            'is_payable': invoice.is_payable,
            'pay_url': reverse('store:pay_invoice', args=[invoice.id]),
        } if invoice else None,
    }


def _notify(user_id, title, message, link):
    try:
        UserNotification.objects.create(user_id=user_id, title=title, message=message, link=link)
    except Exception:
        logging.getLogger(__name__).exception('Chat notification failed')


@login_required
def start_conversation(req, product_id):
    """Open (or reopen) the buyer's thread with this product's seller."""
    product = get_object_or_404(Product.objects.select_related('seller', 'seller__user'),
                                id=product_id, is_active=True)
    if not product.seller:
        messages.error(req, 'This product has no seller to chat with.')
        return redirect('store:product_detail', slug=product.slug)
    if product.seller.user_id == req.user.id:
        messages.info(req, 'This is your own product.')
        return redirect('store:product_detail', slug=product.slug)

    conv, _ = Conversation.objects.get_or_create(
        product=product, buyer=req.user, defaults={'seller': product.seller})
    if req.headers.get('x-requested-with') == 'XMLHttpRequest':
        return JsonResponse({'success': True, 'conversation_id': conv.id,
                             'has_location': conv.has_location,
                             'url': reverse('store:chat_thread', args=[conv.id])})
    return redirect('store:chat_thread', conversation_id=conv.id)


@login_required
def chat_inbox(req):
    """All threads this user takes part in — as buyer, as seller, or both."""
    convs = Conversation.objects.filter(
        Q(buyer=req.user) | Q(seller__user=req.user)
    ).select_related('product', 'buyer', 'seller').distinct()

    threads = []
    for conv in convs:
        threads.append({
            'conversation': conv,
            'is_seller_side': conv.seller.user_id == req.user.id,
            'counterparty': conv.other_party(req.user),
            'last_message': conv.messages.filter(is_deleted=False).last(),
            'unread': conv.unread_count_for(req.user),
        })
    return render(req, 'store/chat_inbox.html', {'threads': threads})


@login_required
def chat_thread(req, conversation_id):
    conv = _get_conversation_or_404(req.user, conversation_id)
    is_seller_side = conv.seller.user_id == req.user.id
    conv.messages.filter(is_read=False).exclude(sender_id=req.user.id).update(is_read=True)
    return render(req, 'store/chat_thread.html', {
        'conversation': conv,
        'product': conv.product,
        'is_seller_side': is_seller_side,
        'counterparty': conv.other_party(req.user),
        'chat_messages': conv.messages.select_related('sender', 'invoice', 'invoice__product'),
        'latest_invoice': conv.latest_invoice,
        'last_message_id': conv.messages.order_by('-id').values_list('id', flat=True).first() or 0,
    })


@login_required
def chat_messages(req, conversation_id):
    """Polling endpoint: messages newer than ?after=<id>."""
    conv = _get_conversation_or_404(req.user, conversation_id)
    qs = conv.messages.select_related('sender', 'invoice', 'invoice__product')
    try:
        after = int(req.GET.get('after', 0))
    except (TypeError, ValueError):
        after = 0
    if after:
        qs = qs.filter(id__gt=after)
    payload = [_chat_message_payload(m, req.user) for m in qs]
    conv.messages.filter(is_read=False).exclude(sender_id=req.user.id).update(is_read=True)

    # Also tell the sender which of their existing messages have now been viewed.
    read_ids = list(
        conv.messages.filter(sender_id=req.user.id, is_read=True)
        .values_list('id', flat=True)
    )
    return JsonResponse({
        'success': True,
        'messages': payload,
        'read_ids': read_ids,
        'has_location': conv.has_location,
    })


@login_required
@require_POST
def chat_send(req, conversation_id):
    conv = _get_conversation_or_404(req.user, conversation_id)
    body = (req.POST.get('body') or '').strip()
    if not body:
        return JsonResponse({'success': False, 'error': 'Type a message first.'}, status=400)
    if len(body) > 2000:
        return JsonResponse({'success': False, 'error': 'Message is too long.'}, status=400)

    is_buyer = conv.buyer_id == req.user.id
    # Location is optional during normal conversation. The buyer can chat
    # freely and only shares a region + town when they are ready to purchase.

    msg = ChatMessage.objects.create(conversation=conv, sender=req.user, body=body)
    conv.save(update_fields=['updated_at'])

    recipient_id = conv.seller.user_id if is_buyer else conv.buyer_id
    _notify(recipient_id, f'💬 New message from {req.user.username}',
            body[:120], reverse('store:chat_thread', args=[conv.id]))

    return JsonResponse({'success': True, 'message': _chat_message_payload(msg, req.user)})


@login_required
@require_POST
def chat_delete_conversation(req, conversation_id):
    """Delete an entire chat conversation for either participant."""
    conv = _get_conversation_or_404(req.user, conversation_id)
    conv.delete()
    return JsonResponse({'success': True, 'conversation_id': conversation_id})


@login_required
@require_POST
def chat_delete_message(req, conversation_id, message_id):
    """Soft-delete one message authored by the current buyer or seller."""
    conv = _get_conversation_or_404(req.user, conversation_id)
    msg = get_object_or_404(ChatMessage, id=message_id, conversation=conv)
    if msg.sender_id != req.user.id:
        return JsonResponse({'success': False, 'error': 'You can only delete your own messages.'}, status=403)
    if msg.is_deleted:
        return JsonResponse({'success': True, 'message_id': msg.id})
    msg.is_deleted = True
    msg.deleted_at = timezone.now()
    msg.body = ''
    msg.save(update_fields=['is_deleted', 'deleted_at', 'body'])
    return JsonResponse({'success': True, 'message_id': msg.id})


@login_required
@require_POST
def chat_share_location(req, conversation_id):
    """Buyer manually enters a region and town for delivery."""
    conv = _get_conversation_or_404(req.user, conversation_id)
    if conv.buyer_id != req.user.id:
        return JsonResponse({'success': False, 'error': 'Only the buyer can provide the delivery location.'}, status=403)

    region = (req.POST.get('region') or '').strip()[:100]
    town = (req.POST.get('town') or '').strip()[:100]
    if not region or not town:
        return JsonResponse({
            'success': False,
            'error': 'Enter both your region and town.'
        }, status=400)

    conv.buyer_region = region
    conv.buyer_town = town
    conv.location_shared_at = timezone.now()
    conv.save(update_fields=['buyer_region', 'buyer_town', 'location_shared_at', 'updated_at'])

    label = conv.location_label
    msg = ChatMessage.objects.create(
        conversation=conv, sender=req.user, kind=ChatMessage.LOCATION,
        body=f'Shared delivery location: {label}')
    _notify(conv.seller.user_id, 'Buyer shared a delivery location',
            f'{req.user.username} shared {label} for {conv.product.name}.',
            reverse('store:chat_thread', args=[conv.id]))

    return JsonResponse({'success': True, 'location': label,
                         'message': _chat_message_payload(msg, req.user)})


@login_required
@require_POST
def issue_invoice(req, conversation_id):
    """Seller issues the agreed price + delivery fee. This becomes the amount
    the buyer is charged — the listed product price is only a starting point."""
    conv = _get_conversation_or_404(req.user, conversation_id)
    if conv.seller.user_id != req.user.id:
        return JsonResponse({'success': False, 'error': 'Only the seller can issue an invoice.'}, status=403)

    # A delivery quote can only be prepared after the buyer has voluntarily
    # supplied the region and town. This does not restrict ordinary chat.
    if not conv.has_location:
        return JsonResponse({
            'success': False,
            'code': 'location_required_for_invoice',
            'error': 'Ask the buyer to share their region and town before sending the invoice so you can add the delivery fee.',
        }, status=400)

    try:
        unit_price = Decimal(str(req.POST.get('unit_price'))).quantize(Decimal('0.01'))
        delivery_fee = Decimal(str(req.POST.get('delivery_fee') or '0')).quantize(Decimal('0.01'))
        quantity = max(1, int(float(req.POST.get('quantity') or 1)))
    except (TypeError, ValueError, ArithmeticError):
        return JsonResponse({'success': False, 'error': 'Enter a valid price, fee and quantity.'}, status=400)

    if unit_price <= 0 or delivery_fee < 0:
        return JsonResponse({'success': False, 'error': 'Prices cannot be negative.'}, status=400)
    if conv.product.stock < quantity:
        return JsonResponse({'success': False, 'error': 'You do not have that much stock.'}, status=400)

    color, size = _normalise_variant(conv.product, req.POST.get('color'), req.POST.get('size'))

    with transaction.atomic():
        # Only one open invoice per thread — a new quote replaces the old one.
        conv.invoices.filter(status=Invoice.PENDING).update(status=Invoice.CANCELLED)
        invoice = Invoice.objects.create(
            conversation=conv, product=conv.product, buyer=conv.buyer, seller=conv.seller,
            quantity=quantity, color=color, size=size,
            unit_price=unit_price, delivery_fee=delivery_fee,
            note=(req.POST.get('note') or '').strip()[:1000],
        )
        msg = ChatMessage.objects.create(
            conversation=conv, sender=req.user, kind=ChatMessage.INVOICE, invoice=invoice,
            body=f'Invoice: {quantity} × GH₵{unit_price} + GH₵{delivery_fee} delivery = GH₵{invoice.total}')
    conv.save(update_fields=['updated_at'])

    _notify(conv.buyer_id, '🧾 You have an invoice',
            f'{conv.seller.store_name} sent an invoice of GH₵{invoice.total} for {conv.product.name}.',
            reverse('store:chat_thread', args=[conv.id]))

    return JsonResponse({'success': True, 'message': _chat_message_payload(msg, req.user)})


@login_required
@require_POST
def cancel_invoice(req, invoice_id):
    invoice = get_object_or_404(Invoice.objects.select_related('conversation', 'seller'), id=invoice_id)
    if invoice.seller.user_id != req.user.id:
        return JsonResponse({'success': False, 'error': 'Only the seller can cancel an invoice.'}, status=403)
    if invoice.status != Invoice.PENDING:
        return JsonResponse({'success': False, 'error': 'That invoice is no longer open.'}, status=400)
    invoice.status = Invoice.CANCELLED
    invoice.save(update_fields=['status'])
    ChatMessage.objects.create(conversation=invoice.conversation, sender=req.user,
                               kind=ChatMessage.SYSTEM, body=f'Invoice #{invoice.id} was cancelled.')
    return JsonResponse({'success': True})


@login_required
@require_POST
def decline_invoice(req, invoice_id):
    """Allow the buyer to reject a pending invoice without paying it."""
    invoice = get_object_or_404(
        Invoice.objects.select_related('conversation', 'seller', 'buyer', 'product'),
        id=invoice_id
    )
    if invoice.buyer_id != req.user.id:
        return JsonResponse({'success': False, 'error': 'Only the buyer can decline this invoice.'}, status=403)
    if invoice.status != Invoice.PENDING:
        return JsonResponse({'success': False, 'error': 'That invoice is no longer open.'}, status=400)

    invoice.status = Invoice.DECLINED
    invoice.save(update_fields=['status'])

    ChatMessage.objects.create(
        conversation=invoice.conversation,
        sender=req.user,
        kind=ChatMessage.SYSTEM,
        body=f'Invoice #{invoice.id} was declined by the buyer.'
    )
    _notify(
        invoice.seller.user_id,
        '🧾 Invoice declined',
        f'{req.user.username} declined invoice #{invoice.id} for {invoice.product.name}.',
        reverse('store:chat_thread', args=[invoice.conversation_id])
    )
    return JsonResponse({'success': True})


@login_required
def pay_invoice(req, invoice_id):
    """Buyer accepts the invoice: it becomes the checkout, priced at the
    agreed amount plus the delivery fee."""
    invoice = get_object_or_404(
        Invoice.objects.select_related('product', 'buyer', 'seller', 'conversation'), id=invoice_id)
    if invoice.buyer_id != req.user.id:
        raise Http404('Invoice not found.')
    if invoice.status == Invoice.PAID:
        messages.info(req, 'This invoice has already been paid.')
        return redirect('store:chat_thread', conversation_id=invoice.conversation_id)
    if not invoice.is_payable:
        messages.error(req, 'This invoice is no longer available.')
        return redirect('store:chat_thread', conversation_id=invoice.conversation_id)
    if invoice.product.stock < invoice.quantity:
        messages.error(req, 'The seller no longer has enough stock for this invoice.')
        return redirect('store:chat_thread', conversation_id=invoice.conversation_id)

    # An invoice checkout stands alone: mixing it with the running cart would
    # make the agreed total ambiguous.
    req.session['cart'] = {
        _cart_key(invoice.product.id, invoice.color, invoice.size): {
            'quantity': invoice.quantity, 'color': invoice.color, 'size': invoice.size,
        }
    }
    req.session['invoice_checkout'] = invoice.id
    req.session.pop('shared_purchase', None)
    req.session.modified = True
    return redirect('store:checkout')


def _active_invoice(req):
    """The invoice driving this checkout, if any. Returns None (and clears the
    session flag) when it is missing, not the buyer's, or no longer open."""
    invoice_id = req.session.get('invoice_checkout')
    if not invoice_id or not req.user.is_authenticated:
        return None
    invoice = Invoice.objects.select_related('product', 'seller', 'conversation').filter(
        id=invoice_id, buyer=req.user, status=Invoice.PENDING).first()
    if not invoice:
        req.session.pop('invoice_checkout', None)
        req.session.modified = True
        return None
    return invoice


def _record_invoice_order(req, order, invoice, paid_amount):
    """Write the order line for an invoice purchase at the agreed price,
    decrement stock, mark the invoice paid and tell both parties."""
    with transaction.atomic():
        product = Product.objects.select_for_update().get(id=invoice.product_id)
        qty = min(product.stock, invoice.quantity)
        if qty > 0:
            product.stock -= qty
            product.save(update_fields=['stock'])
        OrderItem.objects.create(
            order=order, product=product, quantity=max(1, qty),
            price=invoice.unit_price,
            subtotal=invoice.unit_price * Decimal(max(1, qty)),
            color=invoice.color, size=invoice.size,
        )
        order.delivery_fee = invoice.delivery_fee
        order.total_amount = paid_amount
        order.save(update_fields=['delivery_fee', 'total_amount'])
        invoice.mark_paid(order)

    ChatMessage.objects.create(
        conversation=invoice.conversation, kind=ChatMessage.SYSTEM,
        body=f'Invoice #{invoice.id} was paid — GH₵{invoice.total} (including GH₵{invoice.delivery_fee} delivery).')
    _notify(invoice.seller.user_id, '💳 Invoice paid',
            f'{order.user.username} paid GH₵{invoice.total} for {invoice.product.name}.',
            reverse('store:order_receipt', args=[order.id]))
